import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, List, Trash2, Heart, ShoppingBag } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link, useNavigate } from "react-router-dom"; // Added useNavigate
import { createPageUrl } from "@/utils";

export default function Lists() {
  const queryClient = useQueryClient();
  const navigate = useNavigate(); // Initialize useNavigate
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newListName, setNewListName] = useState("");
  const [newListDescription, setNewListDescription] = useState("");

  const { data: lists = [], isLoading } = useQuery({
    queryKey: ["productLists"],
    queryFn: async () => {
      const lists = await base44.entities.ProductList.list("-created_date");
      return lists || [];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.ProductList.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["productLists"] });
      setIsCreateOpen(false);
      setNewListName("");
      setNewListDescription("");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.ProductList.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["productLists"] });
    },
  });

  const handleCreate = () => {
    if (newListName.trim()) {
      createMutation.mutate({
        name: newListName,
        description: newListDescription,
        product_ids: [],
        is_favorite: false,
        color: getRandomColor(),
      });
    }
  };

  const getRandomColor = () => {
    const colors = [
      "#10b981",
      "#3b82f6",
      "#8b5cf6",
      "#f59e0b",
      "#ef4444",
      "#ec4899",
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  const getIconForList = (name) => {
    if (name.toLowerCase().includes("favorite")) return Heart;
    if (
      name.toLowerCase().includes("shopping") ||
      name.toLowerCase().includes("buy")
    )
      return ShoppingBag;
    return List;
  };

  const handleViewList = (listId) => {
    // Navigate to a filtered view showing products in this list
    navigate(createPageUrl("History") + `?list=${listId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F]">
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">My Lists</h1>
            <p className="text-gray-400">
              Organize your products into custom lists
            </p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700">
                <Plus className="w-5 h-5 mr-2" />
                Create List
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#151515] border-white/10 text-white">
              <DialogHeader>
                <DialogTitle className="text-xl font-bold">
                  Create New List
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div>
                  <Label className="text-gray-300 mb-2">List Name</Label>
                  <Input
                    value={newListName}
                    onChange={(e) => setNewListName(e.target.value)}
                    placeholder="e.g., Healthy Snacks"
                    className="bg-[#1A1A1A] border-white/10 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-300 mb-2">
                    Description (Optional)
                  </Label>
                  <Input
                    value={newListDescription}
                    onChange={(e) => setNewListDescription(e.target.value)}
                    placeholder="Add a description..."
                    className="bg-[#1A1A1A] border-white/10 text-white"
                  />
                </div>
                <Button
                  onClick={handleCreate}
                  disabled={!newListName.trim() || createMutation.isPending}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  Create List
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Lists Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6)
              .fill(0)
              .map((_, i) => (
                <Card
                  key={i}
                  className="bg-[#151515] border-white/5 rounded-2xl p-6"
                >
                  <Skeleton className="h-24 w-full bg-white/5 rounded-xl" />
                </Card>
              ))}
          </div>
        ) : lists.length === 0 ? (
          <Card className="bg-[#151515] border-white/5 rounded-3xl p-12 text-center">
            <List className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">No lists yet</h3>
            <p className="text-gray-400 mb-6">
              Create your first list to start organizing products
            </p>
            <Button
              onClick={() => setIsCreateOpen(true)}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Create Your First List
            </Button>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lists.map((list) => {
              const Icon = getIconForList(list.name);
              return (
                <Card
                  key={list.id}
                  className="bg-[#151515] border-white/5 rounded-3xl overflow-hidden hover:border-white/10 transition-all group"
                >
                  <div
                    className="h-3"
                    style={{ background: list.color || "#10b981" }}
                  />
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center"
                          style={{ background: `${list.color || "#10b981"}20` }}
                        >
                          <Icon
                            className="w-6 h-6"
                            style={{ color: list.color || "#10b981" }}
                          />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white group-hover:text-emerald-400 transition-colors">
                            {list.name}
                          </h3>
                          {list.is_favorite && (
                            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/20 mt-1">
                              Favorite
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          if (confirm("Delete this list?")) {
                            deleteMutation.mutate(list.id);
                          }
                        }}
                        className="text-gray-400 hover:text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    {list.description && (
                      <p className="text-gray-400 text-sm mb-4">
                        {list.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between">
                      <p className="text-gray-500 text-sm">
                        {list.product_ids?.length || 0} products
                      </p>
                      <Button
                        variant="ghost"
                        onClick={() => handleViewList(list.id)} // Changed onClick to call handleViewList
                        className="text-emerald-400 hover:text-emerald-300"
                      >
                        View List →
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

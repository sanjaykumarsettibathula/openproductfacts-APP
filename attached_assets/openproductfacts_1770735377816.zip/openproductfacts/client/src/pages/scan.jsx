import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { calculateNutriScore } from "@/utils/nutriScore";
import {
  Camera,
  X,
  Loader2,
  AlertCircle,
  Repeat,
  Image as ImageIcon,
  FileText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BarcodeScanner from "@/components/BarcodeScanner";

export default function Scan() {
  const navigate = useNavigate();
  const [scanMode, setScanMode] = useState("barcode");
  const [barcode, setBarcode] = useState("");
  const [productDescription, setProductDescription] = useState("");
  const [capturedImage, setCapturedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loadingMessage, setLoadingMessage] = useState("Processing...");
  const fileInputRef = useRef(null);

  // Handle tab change - ensure camera stops when switching away from barcode
  const handleTabChange = (value) => {
    // Switch to new tab
    setScanMode(value);
    // Clear any errors when switching tabs
    if (value !== "barcode") {
      setError(null);
    }
  };

  const handleScan = async (scannedBarcode) => {
    if (loading) return;

    setLoading(true);
    setError(null);
    setLoadingMessage("Searching for product...");

    try {
      const existingProducts = await base44.entities.Product.filter({
        barcode: scannedBarcode,
      });

      if (existingProducts && existingProducts.length > 0) {
        const product = existingProducts[0];
        await saveToHistory(product);
        navigate(createPageUrl("ProductDetail") + `?id=${product.id}`);
      } else {
        await fetchProductFromAPI(scannedBarcode);
      }
    } catch (err) {
      setError("Failed to fetch product information. Please try again.");
      setLoading(false);
    }
  };

  const handleImageCapture = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError(null);
    setLoadingMessage("Uploading image...");

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setCapturedImage(file_url);

      setLoadingMessage("Analyzing product image with AI...");

      const analysisResult = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this food product image and extract comprehensive information in JSON format. Pay special attention to the ingredients list on the package.

        CRITICAL: For ingredients, extract the COMPLETE list exactly as shown on the package. Do not summarize or truncate. Include:
        - Main ingredients with percentages if shown (e.g., "Refined Wheat Flour (Maida) (73%)")
        - All additives with their codes (e.g., "Raising Agents [503(ii) & 500(ii)]")
        - Preservatives, emulsifiers, colors with codes
        - Any warnings or notes (e.g., "Contains Wheat, Milk")
        
        Parse the ingredients into a clean array where each item is properly separated.
        
        Required JSON structure:
        {
          "product_name": "string",
          "brand": "string",
          "ingredients": ["array of individual ingredients - extract ALL from package, separate by commas"],
          "allergens": ["array - extract from 'Contains' or allergen statements"],
          "nutritional_info": {
            "energy_kcal": number,
            "fat": number,
            "saturated_fat": number,
            "carbohydrates": number,
            "sugars": number,
            "fiber": number,
            "protein": number,
            "salt": number
          },
          "estimated_nutri_score": "A-E based on nutrition",
          "product_category": "string",
          "packaging_materials": ["array of materials"],
          "estimated_price_inr": number,
          "serving_size": "string"
        }`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            product_name: { type: "string" },
            brand: { type: "string" },
            ingredients: { type: "array", items: { type: "string" } },
            allergens: { type: "array", items: { type: "string" } },
            nutritional_info: {
              type: "object",
              properties: {
                energy_kcal: { type: "number" },
                fat: { type: "number" },
                saturated_fat: { type: "number" },
                carbohydrates: { type: "number" },
                sugars: { type: "number" },
                fiber: { type: "number" },
                protein: { type: "number" },
                salt: { type: "number" },
              },
            },
            estimated_nutri_score: { type: "string" },
            product_category: { type: "string" },
            packaging_materials: { type: "array", items: { type: "string" } },
            estimated_price_inr: { type: "number" },
            serving_size: { type: "string" },
          },
        },
      });

      setLoadingMessage("Creating product record...");

      const productData = {
        barcode: `IMG-${Date.now()}`,
        name: analysisResult.product_name || "Unknown Product",
        brand: analysisResult.brand || "Unknown Brand",
        image_url: file_url,
        nutri_score:
          analysisResult.estimated_nutri_score?.toUpperCase() || "unknown",
        eco_score: "unknown",
        nova_group: 0,
        serving_size: analysisResult.serving_size || "100g",
        categories: analysisResult.product_category
          ? [analysisResult.product_category]
          : [],
        ingredients: analysisResult.ingredients || [],
        allergens: analysisResult.allergens || [],
        nutritional_info: {
          energy_kj: analysisResult.nutritional_info?.energy_kcal 
            ? analysisResult.nutritional_info.energy_kcal * 4.184 
            : 0,
          energy_kcal: analysisResult.nutritional_info?.energy_kcal || 0,
          fat: analysisResult.nutritional_info?.fat || 0,
          saturated_fat: analysisResult.nutritional_info?.saturated_fat || 0,
          carbohydrates: analysisResult.nutritional_info?.carbohydrates || 0,
          sugars: analysisResult.nutritional_info?.sugars || 0,
          fiber: analysisResult.nutritional_info?.fiber || 0,
          protein: analysisResult.nutritional_info?.protein || 0,
          salt: analysisResult.nutritional_info?.salt || 0,
          sodium: analysisResult.nutritional_info?.salt 
            ? analysisResult.nutritional_info.salt / 2.5 
            : 0,
        },
        nutri_score_details: calculateNutriScore({
          energy_kj: analysisResult.nutritional_info?.energy_kcal 
            ? analysisResult.nutritional_info.energy_kcal * 4.184 
            : 0,
          energy_kcal: analysisResult.nutritional_info?.energy_kcal || 0,
          fat: analysisResult.nutritional_info?.fat || 0,
          saturated_fat: analysisResult.nutritional_info?.saturated_fat || 0,
          carbohydrates: analysisResult.nutritional_info?.carbohydrates || 0,
          sugars: analysisResult.nutritional_info?.sugars || 0,
          fiber: analysisResult.nutritional_info?.fiber || 0,
          protein: analysisResult.nutritional_info?.protein || 0,
          salt: analysisResult.nutritional_info?.salt || 0,
        }),
        packaging: {
          materials: analysisResult.packaging_materials || [],
          recycling: "Check local guidelines",
        },
        countries_sold: ["India"],
        price: analysisResult.estimated_price_inr || 0,
        currency: "INR",
      };

      const savedProduct = await base44.entities.Product.create(productData);
      await saveToHistory(savedProduct);
      navigate(createPageUrl("ProductDetail") + `?id=${savedProduct.id}`);
    } catch (err) {
      setError(
        "Failed to analyze product image. Please try again or use manual entry."
      );
      setLoading(false);
    }
  };

  const handleManualSubmit = async (e) => {
    e.preventDefault();

    if (!barcode.trim() && !productDescription.trim()) {
      setError("Please enter either a barcode or product description");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      if (barcode.trim()) {
        await handleScan(barcode.trim());
      } else if (productDescription.trim()) {
        setLoadingMessage("Analyzing product description with AI...");

        const analysisResult = await base44.integrations.Core.InvokeLLM({
          prompt: `Based on this product description: "${productDescription}", provide comprehensive nutritional analysis and details in JSON format:
          
          Required fields:
          - product_name (string)
          - brand (string, or "Unknown" if not specified)
          - estimated_nutritional_info (object with reasonable estimates for energy_kcal, fat, saturated_fat, carbohydrates, sugars, fiber, protein, salt per 100g)
          - estimated_nutri_score (A-E based on typical products in this category)
          - likely_ingredients (array of strings - common ingredients for this type of product)
          - likely_allergens (array of strings - common allergens in this product type)
          - product_category (string)
          - packaging_materials (array of strings - typical packaging for this product)
          - estimated_price_inr (number - typical Indian retail price)
          - serving_size (string)`,
          add_context_from_internet: true,
          response_json_schema: {
            type: "object",
            properties: {
              product_name: { type: "string" },
              brand: { type: "string" },
              estimated_nutritional_info: {
                type: "object",
                properties: {
                  energy_kcal: { type: "number" },
                  fat: { type: "number" },
                  saturated_fat: { type: "number" },
                  carbohydrates: { type: "number" },
                  sugars: { type: "number" },
                  fiber: { type: "number" },
                  protein: { type: "number" },
                  salt: { type: "number" },
                },
              },
              estimated_nutri_score: { type: "string" },
              likely_ingredients: { type: "array", items: { type: "string" } },
              likely_allergens: { type: "array", items: { type: "string" } },
              product_category: { type: "string" },
              packaging_materials: { type: "array", items: { type: "string" } },
              estimated_price_inr: { type: "number" },
              serving_size: { type: "string" },
            },
          },
        });

        setLoadingMessage("Creating product record...");

        const productData = {
          barcode: `TXT-${Date.now()}`,
          name: analysisResult.product_name || productDescription,
          brand: analysisResult.brand || "Unknown Brand",
          image_url: "",
          nutri_score:
            analysisResult.estimated_nutri_score?.toUpperCase() || "unknown",
          eco_score: "unknown",
          nova_group: 0,
          serving_size: analysisResult.serving_size || "100g",
          categories: analysisResult.product_category
            ? [analysisResult.product_category]
            : [],
          ingredients: analysisResult.likely_ingredients || [],
          allergens: analysisResult.likely_allergens || [],
          nutritional_info: {
            energy_kj: analysisResult.estimated_nutritional_info?.energy_kcal
              ? analysisResult.estimated_nutritional_info.energy_kcal * 4.184
              : 0,
            energy_kcal:
              analysisResult.estimated_nutritional_info?.energy_kcal || 0,
            fat: analysisResult.estimated_nutritional_info?.fat || 0,
            saturated_fat:
              analysisResult.estimated_nutritional_info?.saturated_fat || 0,
            carbohydrates:
              analysisResult.estimated_nutritional_info?.carbohydrates || 0,
            sugars: analysisResult.estimated_nutritional_info?.sugars || 0,
            fiber: analysisResult.estimated_nutritional_info?.fiber || 0,
            protein: analysisResult.estimated_nutritional_info?.protein || 0,
            salt: analysisResult.estimated_nutritional_info?.salt || 0,
            sodium: analysisResult.estimated_nutritional_info?.salt
              ? analysisResult.estimated_nutritional_info.salt / 2.5
              : 0,
          },
          nutri_score_details: calculateNutriScore({
            energy_kj: analysisResult.estimated_nutritional_info?.energy_kcal
              ? analysisResult.estimated_nutritional_info.energy_kcal * 4.184
              : 0,
            energy_kcal:
              analysisResult.estimated_nutritional_info?.energy_kcal || 0,
            fat: analysisResult.estimated_nutritional_info?.fat || 0,
            saturated_fat:
              analysisResult.estimated_nutritional_info?.saturated_fat || 0,
            carbohydrates:
              analysisResult.estimated_nutritional_info?.carbohydrates || 0,
            sugars: analysisResult.estimated_nutritional_info?.sugars || 0,
            fiber: analysisResult.estimated_nutritional_info?.fiber || 0,
            protein: analysisResult.estimated_nutritional_info?.protein || 0,
            salt: analysisResult.estimated_nutritional_info?.salt || 0,
          }),
          packaging: {
            materials: analysisResult.packaging_materials || [],
            recycling: "Check local guidelines",
          },
          countries_sold: ["India"],
          price: analysisResult.estimated_price_inr || 0,
          currency: "INR",
        };

        const savedProduct = await base44.entities.Product.create(productData);
        await saveToHistory(savedProduct);
        navigate(createPageUrl("ProductDetail") + `?id=${savedProduct.id}`);
      }
    } catch (err) {
      setError("Failed to process your input. Please try again.");
      setLoading(false);
    }
  };

  const fetchProductFromAPI = async (barcode) => {
    try {
      setLoadingMessage("Fetching from Open Food Facts...");
      const response = await fetch(
        `https://world.openfoodfacts.org/api/v2/product/${barcode}.json`
      );
      const data = await response.json();

      if (data.status === 1 && data.product) {
        const apiProduct = data.product;

        setLoadingMessage("Estimating price...");
        let estimatedPrice = 0;
        try {
          const priceEstimate = await base44.integrations.Core.InvokeLLM({
            prompt: `Estimate the typical retail price in India (INR) for this product:
            Product: ${apiProduct.product_name || apiProduct.product_name_en}
            Brand: ${apiProduct.brands}
            Category: ${apiProduct.categories?.split(",")[0] || "food product"}
            
            Provide ONLY a number representing the price in Indian Rupees. No text, just the number.`,
            add_context_from_internet: true,
          });
          estimatedPrice = parseFloat(priceEstimate.trim()) || 0;
        } catch (error) {
          console.log("Could not estimate price");
        }

        const productData = {
          barcode: barcode,
          name:
            apiProduct.product_name ||
            apiProduct.product_name_en ||
            "Unknown Product",
          brand: apiProduct.brands || "Unknown Brand",
          image_url: apiProduct.image_url || apiProduct.image_front_url || "",
          nutri_score: apiProduct.nutriscore_grade?.toUpperCase() || "unknown",
          eco_score: apiProduct.ecoscore_grade?.toUpperCase() || "unknown",
          nova_group: apiProduct.nova_group || 0,
          serving_size: apiProduct.serving_size || "100g",
          categories:
            apiProduct.categories?.split(",").map((c) => c.trim()) || [],
          ingredients:
            apiProduct.ingredients_text?.split(",").map((i) => i.trim()) || [],
          allergens:
            apiProduct.allergens_tags?.map((a) => a.replace("en:", "")) || [],
          nutritional_info: (() => {
            const energy_kcal = apiProduct.nutriments?.energy_kcal ||
              apiProduct.nutriments?.["energy-kcal"] ||
              (apiProduct.nutriments?.energy_kj ? apiProduct.nutriments.energy_kj / 4.184 : 0);
            const energy_kj = apiProduct.nutriments?.energy_kj ||
              (energy_kcal ? energy_kcal * 4.184 : 0);
            const salt = apiProduct.nutriments?.salt ||
              (apiProduct.nutriments?.sodium ? apiProduct.nutriments.sodium * 2.5 : 0);
            const sodium = apiProduct.nutriments?.sodium ||
              (salt ? salt / 2.5 : 0);
            
            return {
              energy_kj: energy_kj,
              energy_kcal: energy_kcal,
              fat: apiProduct.nutriments?.fat || apiProduct.nutriments?.["fat"] || 0,
              saturated_fat:
                apiProduct.nutriments?.saturated_fat ||
                apiProduct.nutriments?.["saturated-fat"] ||
                0,
              carbohydrates: apiProduct.nutriments?.carbohydrates || apiProduct.nutriments?.["carbohydrates"] || 0,
              sugars: apiProduct.nutriments?.sugars || apiProduct.nutriments?.["sugars"] || 0,
              fiber: apiProduct.nutriments?.fiber || apiProduct.nutriments?.["fiber"] || 0,
              protein: apiProduct.nutriments?.proteins || apiProduct.nutriments?.["proteins"] || apiProduct.nutriments?.["protein"] || 0,
              salt: salt,
              sodium: sodium,
              fruits_vegetables_nuts_percentage: apiProduct.nutriments?.["fruits-vegetables-nuts"] || 
                apiProduct.nutriments?.["fruits-vegetables-nuts-estimate"] || 0,
            };
          })(),
          nutri_score_details: calculateNutriScore({
            energy_kj: apiProduct.nutriments?.energy_kj ||
              ((apiProduct.nutriments?.energy_kcal || apiProduct.nutriments?.["energy-kcal"]) 
                ? (apiProduct.nutriments.energy_kcal || apiProduct.nutriments["energy-kcal"]) * 4.184 
                : 0),
            energy_kcal: apiProduct.nutriments?.energy_kcal ||
              apiProduct.nutriments?.["energy-kcal"] ||
              (apiProduct.nutriments?.energy_kj ? apiProduct.nutriments.energy_kj / 4.184 : 0),
            fat: apiProduct.nutriments?.fat || apiProduct.nutriments?.["fat"] || 0,
            saturated_fat:
              apiProduct.nutriments?.saturated_fat ||
              apiProduct.nutriments?.["saturated-fat"] ||
              0,
            carbohydrates: apiProduct.nutriments?.carbohydrates || apiProduct.nutriments?.["carbohydrates"] || 0,
            sugars: apiProduct.nutriments?.sugars || apiProduct.nutriments?.["sugars"] || 0,
            fiber: apiProduct.nutriments?.fiber || apiProduct.nutriments?.["fiber"] || 0,
            protein: apiProduct.nutriments?.proteins || apiProduct.nutriments?.["proteins"] || apiProduct.nutriments?.["protein"] || 0,
            salt: apiProduct.nutriments?.salt ||
              (apiProduct.nutriments?.sodium ? apiProduct.nutriments.sodium * 2.5 : 0),
            fruits_vegetables_nuts_percentage: apiProduct.nutriments?.["fruits-vegetables-nuts"] || 
              apiProduct.nutriments?.["fruits-vegetables-nuts-estimate"] || 0,
          }),
          packaging: {
            materials: apiProduct.packaging_tags || [],
            recycling:
              apiProduct.recycling_instructions || "Check local guidelines",
          },
          countries_sold: apiProduct.countries_tags?.map((c) =>
            c.replace("en:", "")
          ) || ["India"],
          price: estimatedPrice,
          currency: "INR",
        };

        setLoadingMessage("Saving product...");
        const savedProduct = await base44.entities.Product.create(productData);
        await saveToHistory(savedProduct);
        navigate(createPageUrl("ProductDetail") + `?id=${savedProduct.id}`);
      } else {
        setError(
          "Product not found in database. Please try image capture or manual entry."
        );
        setLoading(false);
      }
    } catch (err) {
      setError("Failed to fetch product from database. Please try again.");
      setLoading(false);
    }
  };

  const saveToHistory = async (product) => {
    try {
      const user = await base44.auth.me();
      await base44.entities.ScannedProduct.create({
        product_id: product.id,
        barcode: product.barcode,
        product_name: product.name,
        product_brand: product.brand,
        product_image: product.image_url,
        nutri_score: product.nutri_score,
        eco_score: product.eco_score,
        scanned_at: new Date().toISOString(),
      });
    } catch (err) {
      console.log("Could not save to history:", err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F]">
      <div className="max-w-screen-xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
            Scan Product
          </h1>
          <p className="text-gray-400 text-lg">
            Scan barcode, capture image, or enter details manually
          </p>
        </div>

        {error && (
          <Alert
            variant="destructive"
            className="mb-6 bg-red-500/10 border-red-500/20"
          >
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Card className="bg-[#151515] border-white/5 rounded-3xl overflow-hidden">
          <Tabs value={scanMode} onValueChange={handleTabChange} className="w-full">
            <div className="p-6 pb-0">
              <TabsList className="grid w-full grid-cols-3 bg-[#1A1A1A] p-1 rounded-2xl">
                <TabsTrigger
                  value="barcode"
                  className="rounded-xl data-[state=active]:bg-emerald-600"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Barcode
                </TabsTrigger>
                <TabsTrigger
                  value="image"
                  className="rounded-xl data-[state=active]:bg-emerald-600"
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Image
                </TabsTrigger>
                <TabsTrigger
                  value="manual"
                  className="rounded-xl data-[state=active]:bg-emerald-600"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Manual
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="p-6">
              {loading && (
                <div className="flex flex-col items-center justify-center py-20">
                  <Loader2 className="w-16 h-16 text-emerald-500 animate-spin mb-4" />
                  <p className="text-gray-400 text-lg">{loadingMessage}</p>
                </div>
              )}

              {!loading && (
                <>
                  {/* BARCODE TAB - Only render when barcode tab is active */}
                  {/* Component will be completely unmounted when scanMode changes */}
                  {scanMode === "barcode" && (
                    <BarcodeScanner 
                      key="barcode-scanner"
                      onScan={handleScan} 
                      isActive={true}
                    />
                  )}

                  {/* IMAGE TAB - Only render when image tab is active */}
                  {scanMode === "image" ? (
                    <div className="mt-0" key="image-tab-content">
                      <div className="space-y-6">
                        <div className="text-center py-12">
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/*"
                            onChange={handleImageCapture}
                            className="hidden"
                          />
                        {capturedImage ? (
                          <div className="space-y-4">
                            <img
                              src={capturedImage}
                              alt="Captured product"
                              className="max-w-md mx-auto rounded-2xl"
                            />
                            <Button
                              onClick={() => {
                                setCapturedImage(null);
                                fileInputRef.current?.click();
                              }}
                              variant="outline"
                              className="border-white/10 text-white hover:bg-white/5"
                            >
                              <Repeat className="w-4 h-4 mr-2" />
                              Recapture
                            </Button>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div className="w-48 h-48 mx-auto rounded-3xl bg-[#1A1A1A] border-2 border-dashed border-white/10 flex items-center justify-center">
                              <ImageIcon className="w-24 h-24 text-gray-600" />
                            </div>
                            <Button
                              onClick={() => fileInputRef.current?.click()}
                              className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold px-8 py-6 text-lg rounded-2xl"
                            >
                              <Camera className="w-5 h-5 mr-2" />
                              Capture Product Image
                            </Button>
                            <p className="text-gray-400 text-sm">
                              Take a clear photo of the product packaging
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                    </div>
                  ) : null}

                  {/* MANUAL TAB - Only render when manual tab is active */}
                  {scanMode === "manual" ? (
                    <div className="mt-0" key="manual-tab-content">
                      <form
                        onSubmit={handleManualSubmit}
                        className="max-w-2xl mx-auto space-y-6 py-8"
                      >
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Barcode (Optional)
                        </label>
                        <Input
                          type="text"
                          value={barcode}
                          onChange={(e) => setBarcode(e.target.value)}
                          placeholder="e.g., 3017620422003"
                          className="bg-[#1A1A1A] border-white/10 text-white text-lg h-14"
                        />
                      </div>

                      <div className="text-center text-gray-500 font-medium">
                        OR
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Product Description
                        </label>
                        <Textarea
                          value={productDescription}
                          onChange={(e) =>
                            setProductDescription(e.target.value)
                          }
                          placeholder="Describe the product... (e.g., 'Organic whole wheat bread with seeds' or 'Greek yogurt with honey 150g')"
                          className="bg-[#1A1A1A] border-white/10 text-white min-h-32"
                        />
                        <p className="text-xs text-gray-500 mt-2">
                          Provide details like product name, brand, ingredients,
                          or any nutritional information you know
                        </p>
                      </div>

                      <Button
                        type="submit"
                        disabled={!barcode.trim() && !productDescription.trim()}
                        className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold h-14 text-lg rounded-2xl"
                      >
                        Analyze Product
                      </Button>
                    </form>
                    </div>
                  ) : null}
                </>
              )}
            </div>
          </Tabs>
        </Card>

        {/* Instructions */}
        <div className="mt-8 grid md:grid-cols-3 gap-4">
          <Card className="bg-[#151515] border-white/5 p-6 rounded-2xl">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center mb-4">
              <Camera className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">
              Barcode Scan
            </h3>
            <p className="text-gray-400 text-sm">
              Fast and accurate - scan any product barcode for instant
              nutritional information
            </p>
          </Card>

          <Card className="bg-[#151515] border-white/5 p-6 rounded-2xl">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/20 flex items-center justify-center mb-4">
              <ImageIcon className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">
              Image Capture
            </h3>
            <p className="text-gray-400 text-sm">
              No barcode? Take a photo and let AI analyze the product for you
            </p>
          </Card>

          <Card className="bg-[#151515] border-white/5 p-6 rounded-2xl">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/20 flex items-center justify-center mb-4">
              <FileText className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">
              Manual Entry
            </h3>
            <p className="text-gray-400 text-sm">
              Describe the product in your own words for AI-powered analysis
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}

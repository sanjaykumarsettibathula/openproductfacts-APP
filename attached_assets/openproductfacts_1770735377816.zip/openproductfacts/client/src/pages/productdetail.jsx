
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Edit, DollarSign, Scale, AlertTriangle, Leaf, Package, Globe, Info, TrendingDown, TrendingUp, Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import NutriScoreBadge from "@/components/NutriScoreBadge";
import EcoScoreBadge from "@/components/EcoScoreBadge";
import ChatBot from "@/components/ChatBot";
import { Input } from "@/components/ui/input";
import { createPageUrl } from "@/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function ProductDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [aiInsight, setAiInsight] = useState(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [showPriceDialog, setShowPriceDialog] = useState(false);
  const [newPrice, setNewPrice] = useState('');
  const [fetchingPrice, setFetchingPrice] = useState(false);
  
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');

  const { data: product, isLoading } = useQuery({
    queryKey: ['product', productId],
    queryFn: async () => {
      const products = await base44.entities.Product.filter({ id: productId });
      return products[0];
    },
    enabled: !!productId
  });

  const updatePriceMutation = useMutation({
    mutationFn: async (price) => {
      return await base44.entities.Product.update(product.id, {
        price: parseFloat(price),
        currency: 'INR'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['product', productId] });
      setShowPriceDialog(false);
      setNewPrice('');
    }
  });

  useEffect(() => {
    if (product && !aiInsight && !loadingInsight) {
      generateAIInsight();
    }
  }, [product]);

  useEffect(() => {
    // Fetch price estimate only if product price is not set (0 or null/undefined) and not already fetching
    if (product && (!product.price || product.price === 0) && !fetchingPrice) {
      fetchPriceEstimate();
    }
  }, [product]); // Changed dependency array to prevent re-triggering while already fetching

  const generateAIInsight = async () => {
    if (!product) return;
    setLoadingInsight(true);
    
    try {
      const insight = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this food product and provide a brief, plain-English health impact summary (2-3 sentences):
                Product: ${product.name}
                Nutri-Score: ${product.nutri_score}
                Nutritional Info: ${JSON.stringify(product.nutritional_info)}
                Ingredients: ${product.ingredients?.join(', ') || 'Not available'}
                
                Focus on: overall healthiness, key concerns, and one actionable recommendation.`,
        add_context_from_internet: false
      });
      setAiInsight(insight);
    } catch (error) {
      console.error("Failed to generate AI insight:", error);
    }
    setLoadingInsight(false);
  };

  const fetchPriceEstimate = async () => {
    if (!product) return;
    setFetchingPrice(true);

    try {
      const priceEstimate = await base44.integrations.Core.InvokeLLM({
        prompt: `Estimate the typical retail price in India (INR) for this product:
        Product: ${product.name}
        Brand: ${product.brand}
        Category: ${product.categories?.join(', ') || 'packaged food'}
        Serving Size: ${product.serving_size || '100g'}
        
        Provide ONLY a single number representing the price in INR (Indian Rupees). 
        Consider typical Indian retail prices for similar products.
        Response should be just the number, nothing else.`,
        add_context_from_internet: true
      });

      const estimatedPrice = parseFloat(priceEstimate.trim());
      if (!isNaN(estimatedPrice) && estimatedPrice > 0) {
        await updatePriceMutation.mutateAsync(estimatedPrice.toString());
      }
    } catch (error) {
      console.error("Failed to fetch price estimate:", error);
    }
    setFetchingPrice(false);
  };

  const handleUpdatePrice = async () => {
    if (!newPrice || !product) return;
    await updatePriceMutation.mutateAsync(newPrice);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F] p-4">
        <div className="max-w-4xl mx-auto space-y-4">
          <Skeleton className="h-64 w-full bg-white/5" />
          <Skeleton className="h-32 w-full bg-white/5" />
          <Skeleton className="h-48 w-full bg-white/5" />
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F] flex items-center justify-center p-4">
        <Card className="bg-[#151515] border-white/5 p-8 text-center rounded-3xl">
          <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Product Not Found</h2>
          <p className="text-gray-400 mb-6">The product you're looking for doesn't exist.</p>
          <Button onClick={() => navigate(createPageUrl("Home"))} className="bg-emerald-600 hover:bg-emerald-700">
            Go Home
          </Button>
        </Card>
      </div>
    );
  }

  const nutritionalInfo = product.nutritional_info || {};
  const nutriScoreDetails = product.nutri_score_details || {};

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F]">
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/5"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl md:text-3xl font-bold text-white">{product.name}</h1>
            <p className="text-gray-400 text-lg">{product.brand}</p>
          </div>
        </div>

        {/* Product Image and Scores */}
        <Card className="bg-[#151515] border-white/5 rounded-3xl overflow-hidden">
          <div className="grid md:grid-cols-2 gap-8 p-8">
            {/* Image */}
            <div className="aspect-square bg-[#0F0F0F] rounded-2xl overflow-hidden flex items-center justify-center">
              {product.image_url ? (
                <img src={product.image_url} alt={product.name} className="w-full h-full object-contain p-8" />
              ) : (
                <Package className="w-24 h-24 text-gray-600" />
              )}
            </div>

            {/* Scores and Quick Info */}
            <div className="space-y-6">
              <div>
                <h3 className="text-sm text-gray-400 mb-4">HEALTH SCORES</h3>
                <div className="flex gap-6">
                  <NutriScoreBadge score={product.nutri_score} size="lg" />
                  <EcoScoreBadge score={product.eco_score} size="lg" />
                </div>
              </div>

              {product.serving_size && (
                <div>
                  <p className="text-sm text-gray-400 mb-1">Serving Size</p>
                  <p className="text-2xl font-bold text-white">{product.serving_size}</p>
                </div>
              )}

              {/* Price Display/Edit */}
              <div>
                <p className="text-sm text-gray-400 mb-1">Price</p>
                <div className="flex items-center gap-3">
                  {fetchingPrice ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 text-emerald-500 animate-spin" />
                      <span className="text-gray-400">Fetching price...</span>
                    </div>
                  ) : (
                    <>
                      <p className="text-2xl font-bold text-white">
                        {product.price > 0 ? `₹${product.price.toFixed(2)}` : 'Not set'}
                      </p>
                      {product.price > 0 && (
                        <Badge variant="secondary" className="bg-green-500/20 text-green-400 text-xs">
                          Estimated
                        </Badge>
                      )}
                    </>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => navigate(createPageUrl("Scan"))}
                  className="border-white/10 text-white hover:bg-white/5"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Scan New
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowPriceDialog(true);
                    setNewPrice(product.price?.toString() || '');
                  }}
                  className="border-white/10 text-white hover:bg-white/5"
                >
                  ₹ {product.price > 0 ? 'Edit Price' : 'Add Price'}
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* AI Insight */}
        <Card className="bg-gradient-to-br from-emerald-600/10 via-emerald-500/5 to-transparent border-emerald-500/20 rounded-3xl p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-6 h-6 text-emerald-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-white mb-2">AI Health Insight</h3>
              {loadingInsight ? (
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full bg-white/5" />
                  <Skeleton className="h-4 w-3/4 bg-white/5" />
                </div>
              ) : (
                <p className="text-gray-300 leading-relaxed">{aiInsight || 'Generating insight...'}</p>
              )}
            </div>
          </div>
        </Card>

        {/* Alert Badges */}
        <div className="flex flex-wrap gap-3">
          {product.nutri_score && ['D', 'E'].includes(product.nutri_score.toUpperCase()) && (
            <Badge variant="destructive" className="bg-red-500/20 text-red-400 border-red-500/20 py-2 px-4">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Lower nutritional quality
            </Badge>
          )}
          {!product.categories || product.categories.length === 0 && (
            <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-400 border-yellow-500/20 py-2 px-4">
              <Info className="w-4 h-4 mr-2" />
              Missing precise category
            </Badge>
          )}
        </div>

        {/* Detailed Tabs */}
        <Tabs defaultValue="nutrition" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-[#151515] border border-white/5 p-1 rounded-2xl">
            <TabsTrigger value="nutrition" className="rounded-xl data-[state=active]:bg-emerald-600">
              Nutrition
            </TabsTrigger>
            <TabsTrigger value="ingredients" className="rounded-xl data-[state=active]:bg-emerald-600">
              Ingredients
            </TabsTrigger>
            <TabsTrigger value="environment" className="rounded-xl data-[state=active]:bg-emerald-600">
              Environment
            </TabsTrigger>
            <TabsTrigger value="info" className="rounded-xl data-[state=active]:bg-emerald-600">
              Info
            </TabsTrigger>
          </TabsList>

          {/* Nutrition Tab */}
          <TabsContent value="nutrition" className="mt-6 space-y-6">
            <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
              <h3 className="text-xl font-bold text-white mb-6">Nutritional Facts (per 100g)</h3>
              <div className="space-y-0">
                <NutritionRow 
                  label="Energy" 
                  value={nutritionalInfo.energy_kcal !== undefined && nutritionalInfo.energy_kcal !== null ? Math.round(nutritionalInfo.energy_kcal) : 0}
                  unit="kcal"
                  subValue={nutritionalInfo.energy_kj !== undefined && nutritionalInfo.energy_kj !== null ? `${Math.round(nutritionalInfo.energy_kj)} kJ` : (nutritionalInfo.energy_kcal ? `${Math.round((nutritionalInfo.energy_kcal || 0) * 4.184)} kJ` : null)}
                  highlight
                />
                <NutritionRow 
                  label="Fat" 
                  value={nutritionalInfo.fat !== undefined && nutritionalInfo.fat !== null ? nutritionalInfo.fat.toFixed(1) : '0.0'}
                  unit="g"
                  level={getLevel(nutritionalInfo.fat, 'fat')} 
                />
                <NutritionRow 
                  label="Saturated Fat" 
                  value={nutritionalInfo.saturated_fat !== undefined && nutritionalInfo.saturated_fat !== null ? nutritionalInfo.saturated_fat.toFixed(1) : '0.0'}
                  unit="g"
                  level={getLevel(nutritionalInfo.saturated_fat, 'saturated_fat')} 
                  indent 
                />
                <NutritionRow 
                  label="Carbohydrates" 
                  value={nutritionalInfo.carbohydrates !== undefined && nutritionalInfo.carbohydrates !== null ? nutritionalInfo.carbohydrates.toFixed(1) : '0.0'}
                  unit="g"
                />
                <NutritionRow 
                  label="Sugars" 
                  value={nutritionalInfo.sugars !== undefined && nutritionalInfo.sugars !== null ? nutritionalInfo.sugars.toFixed(1) : '0.0'}
                  unit="g"
                  level={getLevel(nutritionalInfo.sugars, 'sugars')} 
                  indent 
                />
                <NutritionRow 
                  label="Fiber" 
                  value={nutritionalInfo.fiber !== undefined && nutritionalInfo.fiber !== null ? nutritionalInfo.fiber.toFixed(1) : '0.0'}
                  unit="g"
                  level={getLevel(nutritionalInfo.fiber, 'fiber')} 
                />
                <NutritionRow 
                  label="Protein" 
                  value={nutritionalInfo.protein !== undefined && nutritionalInfo.protein !== null ? nutritionalInfo.protein.toFixed(1) : '0.0'}
                  unit="g"
                  level={getLevel(nutritionalInfo.protein, 'protein')} 
                />
                <NutritionRow 
                  label="Salt" 
                  value={nutritionalInfo.salt !== undefined && nutritionalInfo.salt !== null ? nutritionalInfo.salt.toFixed(2) : '0.00'}
                  unit="g"
                  level={getLevel(nutritionalInfo.salt, 'salt')} 
                />
              </div>
            </Card>

            {/* Nutri-Score Breakdown */}
            <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
              <h3 className="text-xl font-bold text-white mb-6">Nutri-Score Breakdown</h3>
              
              <div className="space-y-6">
                {/* Negative Points Section */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-red-400 font-semibold flex items-center gap-2">
                      <TrendingDown className="w-5 h-5" />
                      Negative Points
                    </span>
                    <span className="text-2xl font-bold text-white">
                      {nutriScoreDetails?.negative_points !== undefined ? nutriScoreDetails.negative_points : 0}/55
                    </span>
                  </div>
                  <div className="space-y-4">
                    <ScoreRow 
                      label="Energy" 
                      points={nutriScoreDetails?.energy_points || 0} 
                      max={10} 
                      value={nutritionalInfo.energy_kj !== undefined 
                        ? `${Math.round(nutritionalInfo.energy_kj)}kJ` 
                        : (nutritionalInfo.energy_kcal 
                          ? `${Math.round(nutritionalInfo.energy_kcal * 4.184)}kJ` 
                          : '0kJ')}
                      positive={false}
                    />
                    <ScoreRow 
                      label="Sugars" 
                      points={nutriScoreDetails?.sugar_points || 0} 
                      max={15} 
                      value={`${(nutritionalInfo.sugars || 0).toFixed(1)}g`}
                      positive={false}
                    />
                    <ScoreRow 
                      label="Saturated Fat" 
                      points={nutriScoreDetails?.saturated_fat_points || 0} 
                      max={10} 
                      value={`${(nutritionalInfo.saturated_fat || 0).toFixed(1)}g`}
                      positive={false}
                    />
                    <ScoreRow 
                      label="Salt" 
                      points={nutriScoreDetails?.salt_points || 0} 
                      max={20} 
                      value={`${(nutritionalInfo.salt || 0).toFixed(2)}g`}
                      positive={false}
                    />
                  </div>
                </div>

                {/* Positive Points Section */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-green-400 font-semibold flex items-center gap-2">
                      <TrendingUp className="w-5 h-5" />
                      Positive Points
                    </span>
                    <span className="text-2xl font-bold text-white">
                      {nutriScoreDetails?.positive_points !== undefined ? nutriScoreDetails.positive_points : 0}/10
                    </span>
                  </div>
                  <div className="space-y-4">
                    <ScoreRow 
                      label="Fiber" 
                      points={nutriScoreDetails?.fiber_points || 0} 
                      max={5} 
                      value={`${(nutritionalInfo.fiber || 0).toFixed(1)}g`}
                      positive={true}
                    />
                    <ScoreRow 
                      label="Protein" 
                      points={nutriScoreDetails?.protein_points || 0} 
                      max={5} 
                      value={`${(nutritionalInfo.protein || 0).toFixed(1)}g`}
                      positive={true}
                    />
                    <ScoreRow 
                      label="Fruits/Veg/Nuts" 
                      points={nutriScoreDetails?.fruits_vegetables_nuts_points || 0} 
                      max={5} 
                      value={nutritionalInfo.fruits_vegetables_nuts_percentage ? `${nutritionalInfo.fruits_vegetables_nuts_percentage}%` : "Unknown"}
                      positive={true}
                    />
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Ingredients Tab - IMPROVED */}
          <TabsContent value="ingredients" className="mt-6">
            <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
              <div className="mb-6">
                <h3 className="text-xl font-bold text-white mb-2">Ingredients</h3>
                <p className="text-gray-400 text-sm">Complete ingredient list as per package</p>
              </div>
              
              {product.ingredients && product.ingredients.length > 0 ? (
                <div className="space-y-6">
                  {/* Ingredient List with Better Formatting */}
                  <div className="bg-[#1A1A1A] rounded-2xl p-6 border border-white/5">
                    <div className="grid gap-3">
                      {product.ingredients.map((ingredient, index) => (
                        <div key={index} className="flex items-start gap-3 py-2">
                          <span className="text-emerald-400 font-bold text-sm mt-0.5">{index + 1}.</span>
                          <span className="text-gray-200 leading-relaxed flex-1">{ingredient}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Badge View */}
                  <div>
                    <p className="text-sm text-gray-400 mb-3">Quick view:</p>
                    <div className="flex flex-wrap gap-2">
                      {product.ingredients.map((ingredient, index) => (
                        <Badge 
                          key={index} 
                          variant="secondary" 
                          className="bg-white/5 text-gray-300 border border-white/10 py-1.5 px-3"
                        >
                          {ingredient.length > 30 ? ingredient.substring(0, 30) + '...' : ingredient}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Package className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-400">Ingredient information not available</p>
                </div>
              )}

              {/* Allergens Section */}
              {product.allergens && product.allergens.length > 0 && (
                <div className="mt-6 pt-6 border-t border-white/5">
                  <h4 className="font-semibold text-white mb-4 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                    Contains Allergens
                  </h4>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {product.allergens.map((allergen, index) => (
                      <div 
                        key={index}
                        className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-xl p-3"
                      >
                        <div className="w-2 h-2 rounded-full bg-red-500"></div>
                        <span className="text-red-300 font-medium">{allergen}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Environment Tab */}
          <TabsContent value="environment" className="mt-6 space-y-6">
            <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
              <div className="flex items-center gap-3 mb-6">
                <Leaf className="w-6 h-6 text-green-400" />
                <h3 className="text-xl font-bold text-white">Environmental Impact</h3>
              </div>
              
              {/* Eco Score */}
              <div className="mb-6">
                <p className="text-sm text-gray-400 mb-3">Eco-Score Rating</p>
                <div className="flex items-center gap-4">
                  <EcoScoreBadge score={product.eco_score} size="lg" />
                  <div>
                    <p className="text-white font-medium">
                      {product.eco_score && product.eco_score !== 'unknown' 
                        ? `Grade ${product.eco_score.toUpperCase()}`
                        : 'Not yet rated'}
                    </p>
                    <p className="text-gray-400 text-sm">Environmental impact rating</p>
                  </div>
                </div>
              </div>

              {/* Packaging */}
              {product.packaging && (
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-400 mb-3">Packaging Materials</p>
                    {product.packaging.materials && product.packaging.materials.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {product.packaging.materials.map((material, index) => (
                          <Badge key={index} variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                            📦 {material}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">Not specified</p>
                    )}
                  </div>
                  
                  {product.packaging.recycling && (
                    <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
                      <p className="text-sm text-gray-400 mb-2">♻️ Recycling Instructions</p>
                      <p className="text-gray-300">{product.packaging.recycling}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Carbon Footprint Info */}
              <div className="mt-6 bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
                <p className="text-sm text-blue-300">
                  💡 <strong>Tip:</strong> Products with less packaging and local sourcing generally have a lower environmental impact.
                </p>
              </div>
            </Card>
          </TabsContent>

          {/* Info Tab */}
          <TabsContent value="info" className="mt-6">
            <Card className="bg-[#151515] border-white/5 rounded-3xl p-6 space-y-6">
              <div>
                <p className="text-sm text-gray-400 mb-2">Barcode</p>
                <p className="text-xl font-mono text-white">{product.barcode}</p>
              </div>

              {product.categories && product.categories.length > 0 && (
                <div>
                  <p className="text-sm text-gray-400 mb-2">Categories</p>
                  <div className="flex flex-wrap gap-2">
                    {product.categories.map((category, index) => (
                      <Badge key={index} variant="secondary" className="bg-white/5 text-gray-300">
                        {category}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {product.countries_sold && product.countries_sold.length > 0 && (
                <div>
                  <p className="text-sm text-gray-400 mb-2">Countries Where Sold</p>
                  <div className="flex flex-wrap gap-2">
                    {product.countries_sold.map((country, index) => (
                      <Badge key={index} variant="secondary" className="bg-blue-500/20 text-blue-400">
                        <Globe className="w-3 h-3 mr-1" />
                        {country}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Price Edit Dialog */}
      <Dialog open={showPriceDialog} onOpenChange={setShowPriceDialog}>
        <DialogContent className="bg-[#151515] border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Update Price</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Price in INR (₹)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-lg">₹</span>
                <Input
                  type="number"
                  value={newPrice}
                  onChange={(e) => setNewPrice(e.target.value)}
                  placeholder="0.00"
                  className="bg-[#1A1A1A] border-white/10 text-white h-12 pl-10"
                />
              </div>
            </div>
            <Button
              onClick={handleUpdatePrice}
              disabled={!newPrice || updatePriceMutation.isPending}
              className="w-full bg-emerald-600 hover:bg-emerald-700 h-12"
            >
              {updatePriceMutation.isPending ? 'Updating...' : 'Update Price'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* AI Chatbot */}
      <ChatBot contextProduct={product} />
    </div>
  );
}

// Helper Components
function NutritionRow({ label, value, unit, subValue, level, indent, highlight }) {
  return (
    <div
      className={`grid grid-cols-[1fr_auto_auto_auto] sm:grid-cols-[1fr_80px_90px_75px] items-center gap-x-2 sm:gap-x-4 gap-y-0 py-3 px-3 sm:px-4 border-b border-white/5 ${
        indent ? 'pl-8 sm:pl-12' : ''
      } ${
        highlight 
          ? 'bg-gradient-to-r from-emerald-500/10 to-transparent -mx-3 sm:-mx-4 mx-0 px-5 sm:px-6 rounded-lg' 
          : ''
      }`}
    >
      {/* Label Column - Takes available space, left-aligned */}
      <div className={`${highlight ? 'font-bold text-base' : 'font-medium text-sm'} text-gray-300 min-w-0 pr-2 overflow-hidden`}>
        <span className="block truncate">{label}</span>
      </div>

      {/* Sub-value Column (kJ) - Fixed width on desktop, auto on mobile, right-aligned */}
      <div className="text-right w-[70px] sm:w-[80px] flex-shrink-0">
        {subValue ? (
          <span className="text-gray-500 text-xs sm:text-sm whitespace-nowrap block">{subValue}</span>
        ) : (
          <span className="text-gray-500 text-xs sm:text-sm whitespace-nowrap opacity-0 pointer-events-none select-none block">0 kJ</span>
        )}
      </div>

      {/* Value + Unit Column - Fixed width, right-aligned */}
      <div className={`text-right w-[75px] sm:w-[90px] flex-shrink-0 ${
        highlight ? 'font-bold text-lg sm:text-xl text-white' : 'font-semibold text-sm sm:text-base text-white'
      }`}>
        <span className="tabular-nums whitespace-nowrap block">
          {value} {unit}
        </span>
      </div>

      {/* Badge Column - Fixed width, right-aligned, always reserves space */}
      <div className="text-right w-[60px] sm:w-[75px] flex-shrink-0 flex justify-end items-center">
        {level ? (
          <LevelBadge level={level} />
        ) : (
          <span className="inline-block w-full"></span>
        )}
      </div>
    </div>
  );
}

function ScoreRow({ label, points, max, value, positive }) {
  const safePoints = points !== undefined && points !== null ? points : 0;
  const safeMax = max || 1;
  const percentage = Math.min((safePoints / safeMax) * 100, 100);
  const color = positive ? 'green' : 'red';
  
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center text-sm">
        <span className="text-gray-300 font-medium">{label}</span>
        <span className="text-gray-300">
          {safePoints}/{max} points • {value}
        </span>
      </div>
      <div className="relative w-full h-2 bg-gray-800 rounded-full overflow-hidden">
        <div 
          className={`h-full ${positive ? 'bg-green-500' : 'bg-red-500'} transition-all duration-300`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

function LevelBadge({ level }) {
  const colors = {
    low: 'bg-green-500/20 text-green-400 border-green-500/30',
    moderate: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    high: 'bg-red-500/20 text-red-400 border-red-500/30'
  };
  return (
    <Badge 
      variant="secondary" 
      className={`${colors[level]} text-[10px] sm:text-xs border px-2 sm:px-2.5 py-0.5 font-medium rounded-full whitespace-nowrap inline-flex items-center justify-center w-fit`}
    >
      {level}
    </Badge>
  );
}

function getLevel(value, nutrient) {
  const thresholds = {
    fat: { moderate: 3, high: 17.5 },
    saturated_fat: { moderate: 1.5, high: 5 },
    sugars: { moderate: 5, high: 22.5 },
    salt: { moderate: 0.3, high: 1.5 },
    fiber: { low: 3, moderate: 6 },
    protein: { low: 8, moderate: 16 }
  };

  if (!thresholds[nutrient] || value === undefined) return null;
  
  const t = thresholds[nutrient];
  
  if (nutrient === 'fiber' || nutrient === 'protein') {
    if (value >= t.moderate) return 'high';
    if (value >= t.low) return 'moderate';
    return 'low';
  } else {
    if (value >= t.high) return 'high';
    if (value >= t.moderate) return 'moderate';
    return 'low';
  }
}

import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Clock, Search, Trash2, Filter, Download } from "lucide-react";
import { format } from "date-fns";
import ProductCard from "@/components/ProductCard";
import { Skeleton } from "@/components/ui/skeleton";

export default function History() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterBy, setFilterBy] = useState("all");
  const [selectedItems, setSelectedItems] = useState([]);

  const { data: scannedProducts = [], isLoading } = useQuery({
    queryKey: ["scannedProducts"],
    queryFn: async () => {
      const scans = await base44.entities.ScannedProduct.list("-scanned_at");
      return scans || [];
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (ids) => {
      for (const id of ids) {
        await base44.entities.ScannedProduct.delete(id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["scannedProducts"] });
      setSelectedItems([]);
    },
  });

  const filteredProducts = scannedProducts.filter((product) => {
    const matchesSearch =
      product.product_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.product_brand?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFilter =
      filterBy === "all" ||
      (filterBy !== "all" &&
        product.nutri_score?.toLowerCase() === filterBy.toLowerCase());

    return matchesSearch && matchesFilter;
  });

  const handleSelectAll = () => {
    if (selectedItems.length === filteredProducts.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(filteredProducts.map((p) => p.id));
    }
  };

  const handleDelete = () => {
    if (
      selectedItems.length > 0 &&
      confirm(`Delete ${selectedItems.length} items?`)
    ) {
      deleteMutation.mutate(selectedItems);
    }
  };

  const exportData = () => {
    const csv = [
      ["Product", "Brand", "Nutri-Score", "Eco-Score", "Scanned Date"],
      ...filteredProducts.map((p) => [
        p.product_name,
        p.product_brand,
        p.nutri_score,
        p.eco_score,
        format(new Date(p.scanned_at || p.created_date), "yyyy-MM-dd HH:mm"),
      ]),
    ]
      .map((row) =>
        row.map((item) => `"${String(item).replace(/"/g, '""')}"`).join(",")
      )
      .join("\n"); // Safely quote and escape items

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "scan-history.csv";
    document.body.appendChild(a); // Append to body to ensure it's clickable in all browsers
    a.click();
    document.body.removeChild(a); // Clean up the element
    URL.revokeObjectURL(url); // Release the object URL
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F]">
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Scan History</h1>
            <p className="text-gray-400">
              {scannedProducts.length} products scanned
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={exportData}
              disabled={filteredProducts.length === 0}
              className="border-white/10 text-white hover:bg-white/5"
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            {selectedItems.length > 0 && (
              <Button
                variant="destructive"
                onClick={handleDelete}
                className="bg-red-600 hover:bg-red-700"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete ({selectedItems.length})
              </Button>
            )}
          </div>
        </div>

        {/* Filters */}
        <Card className="bg-[#151515] border-white/5 rounded-2xl p-4">
          <div className="grid md:grid-cols-3 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="pl-10 bg-[#1A1A1A] border-white/10 text-white"
              />
            </div>
            <Select value={filterBy} onValueChange={setFilterBy}>
              <SelectTrigger className="bg-[#1A1A1A] border-white/10 text-white">
                <SelectValue placeholder="Filter by Nutri-Score" />
              </SelectTrigger>
              <SelectContent className="bg-[#1A1A1A] border-white/10">
                <SelectItem value="all">All Scores</SelectItem>
                <SelectItem value="a">Nutri-Score A</SelectItem>
                <SelectItem value="b">Nutri-Score B</SelectItem>
                <SelectItem value="c">Nutri-Score C</SelectItem>
                <SelectItem value="d">Nutri-Score D</SelectItem>
                <SelectItem value="e">Nutri-Score E</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>

        {/* Selection Controls */}
        {filteredProducts.length > 0 && (
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={handleSelectAll}
              className="text-emerald-400 hover:text-emerald-300"
            >
              {selectedItems.length === filteredProducts.length
                ? "Deselect All"
                : "Select All"}
            </Button>
          </div>
        )}

        {/* Products Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array(8)
              .fill(0)
              .map((_, i) => (
                <Card
                  key={i}
                  className="bg-[#151515] border-white/5 rounded-2xl p-4"
                >
                  <Skeleton className="h-48 w-full bg-white/5 rounded-xl mb-3" />
                  <Skeleton className="h-6 w-3/4 bg-white/5 mb-2" />
                  <Skeleton className="h-4 w-1/2 bg-white/5" />
                </Card>
              ))}
          </div>
        ) : filteredProducts.length === 0 ? (
          <Card className="bg-[#151515] border-white/5 rounded-3xl p-12 text-center">
            <Clock className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">
              {searchQuery || filterBy !== "all"
                ? "No products found"
                : "No scan history yet"}
            </h3>
            <p className="text-gray-400 mb-6">
              {searchQuery || filterBy !== "all"
                ? "Try adjusting your search or filters"
                : "Start scanning products to build your history"}
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredProducts.map((product) => (
              <div key={product.id} className="relative group">
                <div
                  className={`absolute top-2 left-2 z-10 w-6 h-6 rounded-md border-2 cursor-pointer transition-all ${
                    selectedItems.includes(product.id)
                      ? "bg-emerald-500 border-emerald-500"
                      : "bg-transparent border-white/20 hover:border-white/40"
                  }`}
                  onClick={(e) => {
                    e.preventDefault();
                    setSelectedItems((prev) =>
                      prev.includes(product.id)
                        ? prev.filter((id) => id !== product.id)
                        : [...prev, product.id]
                    );
                  }}
                />
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

export default function Login() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [isSignup, setIsSignup] = useState(false);
  const fileInputRef = useRef(null);
  
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });
  
  const [signupData, setSignupData] = useState({
    email: "",
    password: "",
    age: "",
    gender: "male",
    height_cm: "",
    weight_kg: "",
    allergies: "",
    conditions: "",
    notes: "",
    health_report: null,
  });

  const conditionOptions = ["none", "vegetarian", "vegan", "keto", "low-carb", "low-sodium"];
  const [selectedConditions, setSelectedConditions] = useState(["none"]);

  const toggleCondition = (condition) => {
    setSelectedConditions((prev) => {
      if (condition === "none") return ["none"];
      const newConditions = prev.includes(condition)
        ? prev.filter((c) => c !== condition)
        : [...prev.filter((c) => c !== "none"), condition];
      return newConditions.length === 0 ? ["none"] : newConditions;
    });
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const user = await base44.auth.me();
      if (user && user.email) {
        navigate(createPageUrl("Home"));
      }
    } catch (error) {
      // Not logged in
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!loginData.email || !loginData.password) {
        toast.error("Please enter both email and password");
        setLoading(false);
        return;
      }

      await base44.auth.login(loginData.email, loginData.password);
      toast.success("Login successful!");
      navigate(createPageUrl("Home"));
    } catch (err) {
      toast.error(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!signupData.email || !signupData.password) {
        toast.error("Email and password are required");
        setLoading(false);
        return;
      }

      await base44.auth.register(
        signupData.email,
        signupData.password,
        signupData.email.split("@")[0]
      );

      await base44.auth.login(signupData.email, signupData.password);
      const user = await base44.auth.me();

      let health_report_url = "";
      if (signupData.health_report) {
        try {
          const { file_url } = await base44.integrations.Core.UploadFile({
            file: signupData.health_report,
          });
          health_report_url = file_url;
        } catch (error) {
          console.log("Health report upload failed");
        }
      }

      const preferencesData = {
        created_by: user.email,
        age: signupData.age ? parseInt(signupData.age) : null,
        gender: signupData.gender,
        height_cm: signupData.height_cm ? parseInt(signupData.height_cm) : null,
        weight_kg: signupData.weight_kg ? parseInt(signupData.weight_kg) : null,
        allergies: signupData.allergies,
        conditions: selectedConditions.filter((c) => c !== "none"),
        dietary_restrictions: selectedConditions.filter((c) => c !== "none"),
        notes: signupData.notes,
        health_report_url: health_report_url,
        nutritional_goals: {
          max_sugar_per_100g: 15,
          max_sodium_per_100g: 1,
          min_protein_per_100g: 5,
          min_fiber_per_100g: 3,
          max_saturated_fat_per_100g: 5,
        },
        dark_mode: true,
        language: "en",
        notifications_enabled: true,
      };

      await base44.entities.UserPreference.create(preferencesData);
      toast.success("Account created!");
      navigate(createPageUrl("Home"));
    } catch (err) {
      toast.error(err.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {!isSignup ? (
          <div className="bg-[#1a1a1a] rounded-2xl p-8">
            <h1 className="text-2xl font-bold text-white mb-6">Login</h1>
            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="email"
                value={loginData.email}
                onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                placeholder="Email"
                className="w-full bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
              <input
                type="password"
                value={loginData.password}
                onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                placeholder="Password"
                className="w-full bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                required
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold py-3 rounded-lg disabled:opacity-50"
              >
                {loading ? "Signing in..." : "Sign in"}
              </button>
            </form>
            <button
              onClick={() => setIsSignup(true)}
              className="w-full text-emerald-500 hover:text-emerald-400 text-sm mt-6"
            >
              New here? Create an account
            </button>
          </div>
        ) : (
          <div className="bg-[#1a1a1a] rounded-2xl p-8 max-h-[90vh] overflow-y-auto">
            <h1 className="text-2xl font-bold text-white mb-6">Create account</h1>
            <form onSubmit={handleSignup} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="email"
                  value={signupData.email}
                  onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                  placeholder="Email"
                  className="bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
                <input
                  type="password"
                  value={signupData.password}
                  onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                  placeholder="Password"
                  className="bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="number"
                  value={signupData.age}
                  onChange={(e) => setSignupData({ ...signupData, age: e.target.value })}
                  placeholder="Age"
                  className="bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
                <div className="flex gap-2 bg-[#2a2a2a] rounded-lg p-1">
                  {["male", "female", "other"].map((gender) => (
                    <button
                      key={gender}
                      type="button"
                      onClick={() => setSignupData({ ...signupData, gender })}
                      className={`flex-1 py-2 rounded-md text-sm font-medium capitalize ${
                        signupData.gender === gender
                          ? "bg-[#3a3a3a] text-white"
                          : "text-gray-400"
                      }`}
                    >
                      {gender}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="number"
                  value={signupData.height_cm}
                  onChange={(e) => setSignupData({ ...signupData, height_cm: e.target.value })}
                  placeholder="Height (cm)"
                  className="bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
                <input
                  type="number"
                  value={signupData.weight_kg}
                  onChange={(e) => setSignupData({ ...signupData, weight_kg: e.target.value })}
                  placeholder="Weight (kg)"
                  className="bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <input
                type="text"
                value={signupData.allergies}
                onChange={(e) => setSignupData({ ...signupData, allergies: e.target.value })}
                placeholder="Allergies (comma separated)"
                className="w-full bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <input
                type="text"
                value={signupData.conditions}
                onChange={(e) => setSignupData({ ...signupData, conditions: e.target.value })}
                placeholder="Conditions (comma separated)"
                className="w-full bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <div className="flex flex-wrap gap-2">
                {conditionOptions.map((condition) => (
                  <button
                    key={condition}
                    type="button"
                    onClick={() => toggleCondition(condition)}
                    className={`px-4 py-2 rounded-full text-sm capitalize ${
                      selectedConditions.includes(condition)
                        ? "bg-emerald-500 text-white"
                        : "bg-[#2a2a2a] text-gray-400"
                    }`}
                  >
                    {condition}
                  </button>
                ))}
              </div>
              <textarea
                value={signupData.notes}
                onChange={(e) => setSignupData({ ...signupData, notes: e.target.value })}
                placeholder="Notes"
                rows={3}
                className="w-full bg-[#2a2a2a] text-white px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 resize-none"
              />
              <div>
                <p className="text-gray-400 text-sm mb-2">Upload health report (optional)</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={(e) => setSignupData({ ...signupData, health_report: e.target.files?.[0] })}
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-[#2a2a2a] text-gray-400 px-4 py-3 rounded-lg text-left"
                >
                  {signupData.health_report ? signupData.health_report.name : "Choose file"}
                </button>
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-semibold py-3 rounded-lg disabled:opacity-50"
              >
                {loading ? "Creating..." : "Sign up"}
              </button>
            </form>
            <button
              onClick={() => setIsSignup(false)}
              className="w-full text-emerald-500 hover:text-emerald-400 text-sm mt-6"
            >
              Already have an account? Log in
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

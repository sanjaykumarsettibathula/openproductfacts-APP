import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  TrendingUp,
  Heart,
  Shield,
  Leaf,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import ProductCard from "@/components/ProductCard";
import ChatBot from "@/components/ChatBot";

export default function Home() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [hasCheckedOnboarding, setHasCheckedOnboarding] = useState(false);

  const { data: recentScans = [], isLoading: scansLoading } = useQuery({
    queryKey: ["recentScans"],
    queryFn: async () => {
      try {
        const scans = await base44.entities.ScannedProduct.list(
          "-scanned_at",
          5
        );
        return scans || [];
      } catch (error) {
        return [];
      }
    },
  });

  const { data: preferences } = useQuery({
    queryKey: ["userPreferences"],
    queryFn: async () => {
      try {
        const currentUser = await base44.auth.me();
        const prefs = await base44.entities.UserPreference.filter({
          created_by: currentUser.email,
        });
        return prefs[0];
      } catch (error) {
        return null;
      }
    },
  });

  const { data: favoriteLists = [] } = useQuery({
    queryKey: ["favoriteLists"],
    queryFn: async () => {
      try {
        const lists = await base44.entities.ProductList.filter({
          is_favorite: true,
        });
        return lists || [];
      } catch (error) {
        return [];
      }
    },
  });

  useEffect(() => {
    const checkOnboarding = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        // Check if user has completed onboarding
        const prefs = await base44.entities.UserPreference.filter({
          created_by: currentUser.email,
        });
        if (!prefs || prefs.length === 0) {
          // Don't auto-redirect - let user use the app and complete onboarding later
          // navigate(createPageUrl("Onboarding"));
          setHasCheckedOnboarding(true);
        } else {
          setHasCheckedOnboarding(true);
        }
      } catch (error) {
        console.log("User not logged in or error checking onboarding");
        setHasCheckedOnboarding(true);
      }
    };

    if (!hasCheckedOnboarding) {
      checkOnboarding();
    }
  }, [hasCheckedOnboarding, navigate]);

  // Calculate safe products (nutri-score A or B)
  const safeProductsCount = recentScans.filter(
    (scan) =>
      scan.nutri_score && ["A", "B"].includes(scan.nutri_score.toUpperCase())
  ).length;

  // Calculate eco-friendly products (eco-score A or B)
  const ecoProductsCount = recentScans.filter(
    (scan) =>
      scan.eco_score && ["A", "B"].includes(scan.eco_score.toUpperCase())
  ).length;

  const quickStats = [
    {
      icon: TrendingUp,
      label: "Scanned",
      value: recentScans.length,
      color: "text-blue-400",
    },
    {
      icon: Heart,
      label: "Favorites",
      value: favoriteLists.length,
      color: "text-pink-400",
    },
    {
      icon: Shield,
      label: "Safe",
      value: safeProductsCount,
      color: "text-emerald-400",
    },
    {
      icon: Leaf,
      label: "Eco",
      value: ecoProductsCount,
      color: "text-green-400",
    },
  ];

  // Don't block rendering while checking onboarding - let it happen in background
  // if (!hasCheckedOnboarding) {
  //   return (
  //     <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] via-[#0F0F0F] to-[#0A0A0A] flex items-center justify-center">
  //       <div className="text-center">
  //         <div className="w-16 h-16 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin mx-auto mb-4"></div>
  //         <p className="text-gray-400">Loading...</p>
  //       </div>
  //     </div>
  //   );
  // }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] via-[#0F0F0F] to-[#0A0A0A]">
      <div className="max-w-screen-xl mx-auto px-4 py-6 md:py-8 space-y-6 md:space-y-8">
        {/* Hero Section - Green Gradient Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-500 to-teal-600 p-6 md:p-8">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2 md:mb-3">
              <Sparkles className="w-4 h-4 md:w-5 md:h-5 text-white/90" />
              <span className="text-white/90 text-xs md:text-sm font-medium">
                AI-Powered Nutrition
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-2 md:mb-3">
              {user
                ? `Welcome back, ${user.full_name?.split(" ")[0] || "there"}!`
                : "Welcome to FoodScan AI"}
            </h1>
            <p className="text-white/80 text-sm md:text-base lg:text-lg mb-4 md:mb-6 max-w-2xl">
              Scan products instantly, get AI-powered insights, and make
              healthier choices for you and the planet.
            </p>
            <Link to={createPageUrl("Scan")}>
              <Button className="bg-white text-emerald-600 hover:bg-white/90 font-semibold px-6 md:px-8 py-4 md:py-6 text-base md:text-lg rounded-2xl shadow-xl w-full md:w-auto">
                Start Scanning
                <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2" />
              </Button>
            </Link>
          </div>
          <div className="absolute top-0 right-0 w-48 md:w-64 h-48 md:h-64 bg-white/10 rounded-full -mr-24 md:-mr-32 -mt-24 md:-mt-32 blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-36 md:w-48 h-36 md:h-48 bg-teal-400/20 rounded-full -ml-18 md:-ml-24 -mb-18 md:-mb-24 blur-3xl"></div>
        </div>

        {/* Quick Stats - 4 Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {quickStats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card
                key={stat.label}
                className="bg-[#151515] border-white/5 p-4 md:p-6 rounded-2xl hover:border-white/10 transition-all"
              >
                <Icon className={`w-6 h-6 md:w-8 md:h-8 ${stat.color} mb-2 md:mb-3`} />
                <p className="text-2xl md:text-3xl font-bold text-white mb-1">
                  {typeof stat.value === "number"
                    ? stat.value.toString()
                    : stat.value}
                </p>
                <p className="text-xs md:text-sm text-gray-400">{stat.label}</p>
              </Card>
            );
          })}
        </div>

        {/* Recent Scans Section */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl md:text-2xl font-bold text-white">Recent Scans</h2>
              <p className="text-gray-400 text-xs md:text-sm">
                Your latest scanned products
              </p>
            </div>
            <Link to={createPageUrl("History")}>
              <Button
                variant="ghost"
                className="text-emerald-400 hover:text-emerald-300 text-sm md:text-base"
              >
                View All
                <ArrowRight className="w-3 h-3 md:w-4 md:h-4 ml-1 md:ml-2" />
              </Button>
            </Link>
          </div>

          {recentScans.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {scansLoading
                ? Array(3)
                    .fill(0)
                    .map((_, i) => (
                      <Card
                        key={i}
                        className="bg-[#151515] border-white/5 p-4 rounded-2xl"
                      >
                        <Skeleton className="h-40 w-full bg-white/5 rounded-xl mb-3" />
                        <Skeleton className="h-6 w-3/4 bg-white/5 mb-2" />
                        <Skeleton className="h-4 w-1/2 bg-white/5" />
                      </Card>
                    ))
                : recentScans
                    .slice(0, 6)
                    .map((scan) => (
                      <ProductCard key={scan.id} product={scan} />
                    ))}
            </div>
          ) : (
            <Card className="bg-[#151515] border-white/5 p-8 rounded-3xl text-center">
              <p className="text-gray-400 mb-4">No scans yet. Start scanning to see your products here!</p>
              <Link to={createPageUrl("Scan")}>
                <Button className="bg-emerald-600 hover:bg-emerald-700">
                  Start Scanning
                </Button>
              </Link>
            </Card>
          )}
        </div>

        {/* Quick Actions - Compare Products & Set Preferences */}
        <div className="grid md:grid-cols-2 gap-4">
          <Link to={createPageUrl("Compare")}>
            <Card className="bg-gradient-to-br from-blue-600/20 to-blue-500/10 border-blue-500/20 p-5 md:p-6 rounded-2xl hover:border-blue-500/40 transition-all cursor-pointer group">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg md:text-xl font-bold text-white mb-1 md:mb-2">
                    Compare Products
                  </h3>
                  <p className="text-gray-300 text-sm md:text-base">Find healthier alternatives</p>
                </div>
                <ArrowRight className="w-5 h-5 md:w-6 md:h-6 text-blue-400 group-hover:translate-x-2 transition-transform" />
              </div>
            </Card>
          </Link>

          <Link to={createPageUrl("Profile")}>
            <Card className="bg-gradient-to-br from-purple-600/20 to-purple-500/10 border-purple-500/20 p-5 md:p-6 rounded-2xl hover:border-purple-500/40 transition-all cursor-pointer group">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg md:text-xl font-bold text-white mb-1 md:mb-2">
                    Set Preferences
                  </h3>
                  <p className="text-gray-300 text-sm md:text-base">Customize your dietary goals</p>
                </div>
                <ArrowRight className="w-5 h-5 md:w-6 md:h-6 text-purple-400 group-hover:translate-x-2 transition-transform" />
              </div>
            </Card>
          </Link>
        </div>

        {/* Getting Started - Only show when no scans */}
        {recentScans.length === 0 && (
          <Card className="bg-[#151515] border-white/5 p-6 md:p-8 rounded-3xl">
            <h2 className="text-xl md:text-2xl font-bold text-white mb-4">
              Get Started in 3 Easy Steps
            </h2>
            <div className="space-y-4 md:space-y-6">
              <div className="flex gap-3 md:gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xl md:text-2xl font-bold text-emerald-400">1</span>
                </div>
                <div>
                  <h3 className="text-base md:text-lg font-semibold text-white mb-1">
                    Scan a Product
                  </h3>
                  <p className="text-gray-400 text-sm md:text-base">
                    Use your camera to scan any food product barcode
                  </p>
                </div>
              </div>
              <div className="flex gap-3 md:gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xl md:text-2xl font-bold text-blue-400">2</span>
                </div>
                <div>
                  <h3 className="text-base md:text-lg font-semibold text-white mb-1">
                    Get AI Insights
                  </h3>
                  <p className="text-gray-400 text-sm md:text-base">
                    Receive detailed nutritional analysis and health scores
                  </p>
                </div>
              </div>
              <div className="flex gap-3 md:gap-4">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xl md:text-2xl font-bold text-purple-400">3</span>
                </div>
                <div>
                  <h3 className="text-base md:text-lg font-semibold text-white mb-1">
                    Make Better Choices
                  </h3>
                  <p className="text-gray-400 text-sm md:text-base">
                    Get personalized recommendations for healthier alternatives
                  </p>
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>

      {/* AI Chatbot - Floating button and popup */}
      <ChatBot />
    </div>
  );
}

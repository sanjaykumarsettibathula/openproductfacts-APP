import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Scale, Search, X, TrendingUp, TrendingDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import NutriScoreBadge from "@/components/NutriScoreBadge";
import EcoScoreBadge from "@/components/EcoScoreBadge";

export default function Compare() {
  const [searchQuery1, setSearchQuery1] = useState("");
  const [searchQuery2, setSearchQuery2] = useState("");
  const [selectedProduct1, setSelectedProduct1] = useState(null);
  const [selectedProduct2, setSelectedProduct2] = useState(null);

  const { data: allProducts = [], isLoading } = useQuery({
    queryKey: ["allProducts"],
    queryFn: async () => {
      const products = await base44.entities.Product.list("-created_date", 50);
      return products || [];
    },
  });

  const filteredProducts1 = allProducts
    .filter(
      (p) =>
        p.name?.toLowerCase().includes(searchQuery1.toLowerCase()) ||
        p.brand?.toLowerCase().includes(searchQuery1.toLowerCase())
    )
    .slice(0, 5);

  const filteredProducts2 = allProducts
    .filter(
      (p) =>
        p.name?.toLowerCase().includes(searchQuery2.toLowerCase()) ||
        p.brand?.toLowerCase().includes(searchQuery2.toLowerCase())
    )
    .slice(0, 5);

  const compareNutrition = (key) => {
    if (!selectedProduct1 || !selectedProduct2) return null;
    const val1 = selectedProduct1.nutritional_info?.[key] || 0;
    const val2 = selectedProduct2.nutritional_info?.[key] || 0;

    // For negative nutrients (fat, sugar, salt), lower is better
    const negativenutrients = [
      "fat",
      "saturated_fat",
      "sugars",
      "salt",
      "sodium",
    ];
    const isBetter = negativenutrients.includes(key)
      ? val1 < val2
      : val1 > val2;

    return {
      val1,
      val2,
      winner: val1 === val2 ? "tie" : isBetter ? "product1" : "product2",
    };
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F]">
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 mx-auto mb-4 flex items-center justify-center">
            <Scale className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
            Compare Products
          </h1>
          <p className="text-gray-400 text-lg">
            Compare nutritional values side-by-side to make better choices
          </p>
        </div>

        {/* Product Selection */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Product 1 */}
          <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-4">Product 1</h3>
            {!selectedProduct1 ? (
              <div>
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    value={searchQuery1}
                    onChange={(e) => setSearchQuery1(e.target.value)}
                    placeholder="Search products..."
                    className="pl-10 bg-[#1A1A1A] border-white/10 text-white"
                  />
                </div>
                {searchQuery1 && (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {filteredProducts1.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => {
                          setSelectedProduct1(product);
                          setSearchQuery1("");
                        }}
                        className="w-full text-left p-3 rounded-xl bg-[#1A1A1A] hover:bg-[#222] transition-colors"
                      >
                        <p className="font-medium text-white">{product.name}</p>
                        <p className="text-sm text-gray-400">{product.brand}</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div>
                <div className="flex justify-end mb-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedProduct1(null)}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <div className="text-center">
                  <div className="w-32 h-32 mx-auto bg-[#1A1A1A] rounded-2xl mb-4 flex items-center justify-center overflow-hidden">
                    {selectedProduct1.image_url ? (
                      <img
                        src={selectedProduct1.image_url}
                        alt={selectedProduct1.name}
                        className="w-full h-full object-contain p-4"
                      />
                    ) : (
                      <Scale className="w-12 h-12 text-gray-600" />
                    )}
                  </div>
                  <h4 className="font-bold text-white text-lg mb-1">
                    {selectedProduct1.name}
                  </h4>
                  <p className="text-gray-400 mb-4">{selectedProduct1.brand}</p>
                  <div className="flex gap-4 justify-center">
                    <NutriScoreBadge
                      score={selectedProduct1.nutri_score}
                      size="sm"
                    />
                    <EcoScoreBadge
                      score={selectedProduct1.eco_score}
                      size="sm"
                    />
                  </div>
                </div>
              </div>
            )}
          </Card>

          {/* Product 2 */}
          <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-4">Product 2</h3>
            {!selectedProduct2 ? (
              <div>
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    value={searchQuery2}
                    onChange={(e) => setSearchQuery2(e.target.value)}
                    placeholder="Search products..."
                    className="pl-10 bg-[#1A1A1A] border-white/10 text-white"
                  />
                </div>
                {searchQuery2 && (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {filteredProducts2.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => {
                          setSelectedProduct2(product);
                          setSearchQuery2("");
                        }}
                        className="w-full text-left p-3 rounded-xl bg-[#1A1A1A] hover:bg-[#222] transition-colors"
                      >
                        <p className="font-medium text-white">{product.name}</p>
                        <p className="text-sm text-gray-400">{product.brand}</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div>
                <div className="flex justify-end mb-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedProduct2(null)}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <div className="text-center">
                  <div className="w-32 h-32 mx-auto bg-[#1A1A1A] rounded-2xl mb-4 flex items-center justify-center overflow-hidden">
                    {selectedProduct2.image_url ? (
                      <img
                        src={selectedProduct2.image_url}
                        alt={selectedProduct2.name}
                        className="w-full h-full object-contain p-4"
                      />
                    ) : (
                      <Scale className="w-12 h-12 text-gray-600" />
                    )}
                  </div>
                  <h4 className="font-bold text-white text-lg mb-1">
                    {selectedProduct2.name}
                  </h4>
                  <p className="text-gray-400 mb-4">{selectedProduct2.brand}</p>
                  <div className="flex gap-4 justify-center">
                    <NutriScoreBadge
                      score={selectedProduct2.nutri_score}
                      size="sm"
                    />
                    <EcoScoreBadge
                      score={selectedProduct2.eco_score}
                      size="sm"
                    />
                  </div>
                </div>
              </div>
            )}
          </Card>
        </div>

        {/* Comparison Table */}
        {selectedProduct1 && selectedProduct2 && (
          <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
            <h3 className="text-2xl font-bold text-white mb-6 text-center">
              Nutritional Comparison (per 100g)
            </h3>
            <div className="space-y-3">
              <ComparisonRow
                label="Energy (kcal)"
                value1={selectedProduct1.nutritional_info?.energy_kcal || 0}
                value2={selectedProduct2.nutritional_info?.energy_kcal || 0}
                reverse
              />
              <ComparisonRow
                label="Fat"
                value1={selectedProduct1.nutritional_info?.fat || 0}
                value2={selectedProduct2.nutritional_info?.fat || 0}
                unit="g"
                reverse
              />
              <ComparisonRow
                label="Saturated Fat"
                value1={selectedProduct1.nutritional_info?.saturated_fat || 0}
                value2={selectedProduct2.nutritional_info?.saturated_fat || 0}
                unit="g"
                reverse
              />
              <ComparisonRow
                label="Carbohydrates"
                value1={selectedProduct1.nutritional_info?.carbohydrates || 0}
                value2={selectedProduct2.nutritional_info?.carbohydrates || 0}
                unit="g"
              />
              <ComparisonRow
                label="Sugars"
                value1={selectedProduct1.nutritional_info?.sugars || 0}
                value2={selectedProduct2.nutritional_info?.sugars || 0}
                unit="g"
                reverse
              />
              <ComparisonRow
                label="Fiber"
                value1={selectedProduct1.nutritional_info?.fiber || 0}
                value2={selectedProduct2.nutritional_info?.fiber || 0}
                unit="g"
              />
              <ComparisonRow
                label="Protein"
                value1={selectedProduct1.nutritional_info?.protein || 0}
                value2={selectedProduct2.nutritional_info?.protein || 0}
                unit="g"
              />
              <ComparisonRow
                label="Salt"
                value1={selectedProduct1.nutritional_info?.salt || 0}
                value2={selectedProduct2.nutritional_info?.salt || 0}
                unit="g"
                reverse
              />
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

function ComparisonRow({ label, value1, value2, unit = "", reverse = false }) {
  const isBetter1 = reverse ? value1 < value2 : value1 > value2;
  const isBetter2 = reverse ? value2 < value1 : value2 > value1;

  return (
    <div className="grid grid-cols-3 gap-4 items-center py-3 border-b border-white/5">
      <div
        className={`text-right ${
          isBetter1 && value1 !== value2
            ? "text-emerald-400 font-bold"
            : "text-gray-300"
        }`}
      >
        {value1.toFixed(1)}
        {unit}
        {isBetter1 && value1 !== value2 && (
          <TrendingUp className="w-4 h-4 inline ml-2" />
        )}
      </div>
      <div className="text-center font-medium text-white">{label}</div>
      <div
        className={`text-left ${
          isBetter2 && value1 !== value2
            ? "text-emerald-400 font-bold"
            : "text-gray-300"
        }`}
      >
        {value2.toFixed(1)}
        {unit}
        {isBetter2 && value1 !== value2 && (
          <TrendingUp className="w-4 h-4 inline ml-2" />
        )}
      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  User,
  Settings,
  MapPin,
  LogOut,
  Save,
  Upload,
  X,
  AlertCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Profile() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [editedPreferences, setEditedPreferences] = useState(null);
  const [uploadingReport, setUploadingReport] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [removedAllergies, setRemovedAllergies] = useState([]);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.log("User not logged in");
      }
    };
    loadUser();
  }, []);

  const { data: preferences, isLoading } = useQuery({
    queryKey: ["userPreferences"],
    queryFn: async () => {
      try {
        const currentUser = await base44.auth.me();
        const prefs = await base44.entities.UserPreference.filter({
          created_by: currentUser.email,
        });
        return prefs[0];
      } catch (error) {
        return null;
      }
    },
  });

  useEffect(() => {
    if (preferences) {
      setEditedPreferences(preferences);
      setRemovedAllergies([]);
      setHasUnsavedChanges(false);
    } else {
      setEditedPreferences({
        age: null,
        gender: "male",
        height_cm: null,
        weight_kg: null,
        allergies: "",
        conditions: [],
        custom_conditions: "",
        notes: "",
        health_report_url: "",
        dietary_restrictions: [],
        allergens: [],
        nutritional_goals: {
          max_sugar_per_100g: 15,
          max_sodium_per_100g: 1,
          min_protein_per_100g: 5,
          min_fiber_per_100g: 3,
          max_saturated_fat_per_100g: 5,
        },
        blacklisted_ingredients: [],
        location: { country: "", city: "" },
        preferred_stores: [],
        dark_mode: true,
        language: "en",
        notifications_enabled: true,
      });
    }
  }, [preferences]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (preferences) {
        return await base44.entities.UserPreference.update(
          preferences.id,
          data
        );
      } else {
        return await base44.entities.UserPreference.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["userPreferences"] });
      setHasUnsavedChanges(false);
      setRemovedAllergies([]);
      toast.success("Profile saved successfully!");
    },
    onError: () => {
      toast.error("Failed to save profile");
    },
  });

  const handleSave = () => {
    saveMutation.mutate(editedPreferences);
  };

  const handleFieldChange = (field, value) => {
    setEditedPreferences((prev) => ({
      ...prev,
      [field]: value,
    }));
    setHasUnsavedChanges(true);
  };

  const markAllergyForRemoval = (allergyToRemove) => {
    setRemovedAllergies((prev) => [...prev, allergyToRemove]);
    setHasUnsavedChanges(true);
  };

  const undoRemoveAllergy = (allergy) => {
    setRemovedAllergies((prev) => prev.filter((a) => a !== allergy));
    setHasUnsavedChanges(true);
  };

  const getCurrentAllergies = () => {
    if (!editedPreferences?.allergies) return [];
    const allergiesArray = editedPreferences.allergies
      .split(",")
      .map((a) => a.trim())
      .filter((a) => a);
    return allergiesArray.filter((a) => !removedAllergies.includes(a));
  };

  const applyAllergyChanges = () => {
    const currentAllergies = getCurrentAllergies();
    handleFieldChange("allergies", currentAllergies.join(", "));
  };

  useEffect(() => {
    if (removedAllergies.length > 0) {
      applyAllergyChanges();
    }
  }, [removedAllergies]);

  const toggleCondition = (condition) => {
    const newConditions = editedPreferences.conditions?.includes(condition)
      ? editedPreferences.conditions.filter((c) => c !== condition)
      : [...(editedPreferences.conditions || []), condition];
    handleFieldChange("conditions", newConditions);
  };

  const handleHealthReportUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingReport(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      handleFieldChange("health_report_url", file_url);
      toast.success("Health report uploaded successfully!");
    } catch (error) {
      toast.error("Failed to upload health report");
    }
    setUploadingReport(false);
  };

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
      // Clear all cached data
      queryClient.clear();
      // Redirect to login page
      navigate(createPageUrl("Login"));
      toast.success("Logged out successfully");
    } catch (error) {
      toast.error("Failed to logout");
    }
  };

  if (!editedPreferences) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F] flex items-center justify-center">
        <p className="text-white">Loading...</p>
      </div>
    );
  }

  const conditionOptions = [
    "none",
    "vegetarian",
    "vegan",
    "keto",
    "low-carb",
    "low-sodium",
    "paleo",
    "pescatarian",
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0A0A] to-[#0F0F0F]">
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 mx-auto mb-4 flex items-center justify-center">
            <User className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Profile</h1>
          <p className="text-gray-400">{user?.email}</p>
        </div>

        {/* Unsaved Changes Alert */}
        {hasUnsavedChanges && (
          <Alert className="bg-yellow-500/10 border-yellow-500/20">
            <AlertCircle className="h-4 w-4 text-yellow-400" />
            <AlertDescription className="text-yellow-300">
              You have unsaved changes. Click "Save changes" to update your
              profile.
            </AlertDescription>
          </Alert>
        )}

        {/* Basic Info Card */}
        <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
          <h3 className="text-xl font-bold text-white mb-6">
            Basic Information
          </h3>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Age */}
            <div>
              <Label className="text-gray-300 mb-2 block">Age</Label>
              <Input
                type="number"
                value={editedPreferences.age || ""}
                onChange={(e) =>
                  handleFieldChange("age", parseInt(e.target.value) || null)
                }
                placeholder="22"
                className="bg-[#1A1A1A] border-white/10 text-white h-12"
              />
            </div>

            {/* Gender */}
            <div>
              <Label className="text-gray-300 mb-2 block">Gender</Label>
              <div className="grid grid-cols-3 gap-2 bg-[#1A1A1A] p-1 rounded-xl">
                {["male", "female", "other"].map((gender) => (
                  <button
                    key={gender}
                    type="button"
                    onClick={() => handleFieldChange("gender", gender)}
                    className={`py-2 px-4 rounded-lg font-medium transition-all ${
                      editedPreferences.gender === gender
                        ? "bg-gradient-to-r from-red-500 to-red-600 text-white"
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    {gender}
                  </button>
                ))}
              </div>
            </div>

            {/* Height */}
            <div>
              <Label className="text-gray-300 mb-2 block">Height (cm)</Label>
              <Input
                type="number"
                value={editedPreferences.height_cm || ""}
                onChange={(e) =>
                  handleFieldChange(
                    "height_cm",
                    parseInt(e.target.value) || null
                  )
                }
                placeholder="176"
                className="bg-[#1A1A1A] border-white/10 text-white h-12"
              />
            </div>

            {/* Weight */}
            <div>
              <Label className="text-gray-300 mb-2 block">Weight (kg)</Label>
              <Input
                type="number"
                value={editedPreferences.weight_kg || ""}
                onChange={(e) =>
                  handleFieldChange(
                    "weight_kg",
                    parseInt(e.target.value) || null
                  )
                }
                placeholder="60"
                className="bg-[#1A1A1A] border-white/10 text-white h-12"
              />
            </div>
          </div>
        </Card>

        {/* Allergies - Modern removable badges with save requirement */}
        <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <Label className="text-gray-300 mb-1 block text-lg font-semibold">
                Allergies
              </Label>
              <p className="text-xs text-gray-500">
                AI automatically detects and adds allergies from conversations
              </p>
            </div>
          </div>

          {/* Active Allergies */}
          {getCurrentAllergies().length > 0 && (
            <div className="mb-4">
              <p className="text-sm text-gray-400 mb-3">Active Allergies:</p>
              <div className="flex flex-wrap gap-2">
                {getCurrentAllergies().map((allergy, index) => (
                  <div
                    key={index}
                    className="group flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/20 border border-red-500/30 text-red-300 hover:bg-red-500/30 transition-colors"
                  >
                    <span>{allergy}</span>
                    <button
                      onClick={() => markAllergyForRemoval(allergy)}
                      className="hover:bg-red-500/40 rounded-full p-1 transition-colors"
                      title="Remove allergy"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recently Removed (pending save) */}
          {removedAllergies.length > 0 && (
            <div className="mb-4 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl">
              <p className="text-sm text-yellow-400 mb-2 font-medium">
                Pending Removal (click Save to confirm):
              </p>
              <div className="flex flex-wrap gap-2">
                {removedAllergies.map((allergy, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-500/20 border border-gray-500/30 text-gray-400 line-through"
                  >
                    <span>{allergy}</span>
                    <button
                      onClick={() => undoRemoveAllergy(allergy)}
                      className="hover:bg-gray-500/40 rounded-full p-1 transition-colors"
                      title="Undo removal"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Add New Allergies */}
          <div>
            <Label className="text-gray-300 mb-2 block">
              Add New Allergies (comma-separated):
            </Label>
            <Input
              value={editedPreferences.allergies || ""}
              onChange={(e) => handleFieldChange("allergies", e.target.value)}
              placeholder="e.g., peanuts, shellfish"
              className="bg-[#1A1A1A] border-white/10 text-white h-12"
            />
          </div>
          <p className="text-xs text-gray-500 mt-2">
            💡 The AI chatbot automatically adds allergies you mention. You can
            remove them anytime.
          </p>
        </Card>

        {/* Conditions */}
        <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
          <h3 className="text-lg font-bold text-white mb-2">Conditions</h3>
          <p className="text-gray-400 text-sm mb-4">
            Select dietary preferences or health conditions
          </p>

          <div className="flex flex-wrap gap-3 mb-4">
            {conditionOptions.map((condition) => (
              <button
                key={condition}
                type="button"
                onClick={() => toggleCondition(condition)}
                className={`px-5 py-2.5 rounded-full font-medium transition-all ${
                  editedPreferences.conditions?.includes(condition)
                    ? "bg-gradient-to-r from-red-500 to-red-600 text-white"
                    : "bg-[#1A1A1A] text-gray-400 hover:text-white border border-white/10"
                }`}
              >
                {condition}
              </button>
            ))}
          </div>

          <Label className="text-gray-300 mb-2 block">
            Additional conditions (comma separated)
          </Label>
          <Input
            value={editedPreferences.custom_conditions || ""}
            onChange={(e) =>
              handleFieldChange("custom_conditions", e.target.value)
            }
            placeholder="Add custom conditions..."
            className="bg-[#1A1A1A] border-white/10 text-white h-12"
          />
        </Card>

        {/* Notes */}
        <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
          <Label className="text-gray-300 mb-2 block">Notes</Label>
          <Textarea
            value={editedPreferences.notes || ""}
            onChange={(e) => handleFieldChange("notes", e.target.value)}
            placeholder="Add any additional notes about your health, preferences, or dietary requirements..."
            className="bg-[#1A1A1A] border-white/10 text-white min-h-24"
          />
        </Card>

        {/* Health Report Upload */}
        <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
          <h3 className="text-lg font-bold text-white mb-2">Health Report</h3>
          <p className="text-gray-400 text-sm mb-4">
            Upload your health report (optional)
          </p>

          {editedPreferences.health_report_url ? (
            <div className="flex items-center gap-4 p-4 bg-[#1A1A1A] rounded-xl">
              <div className="flex-1">
                <p className="text-white font-medium">Report uploaded</p>
                <a
                  href={editedPreferences.health_report_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 text-sm hover:underline"
                >
                  View report
                </a>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleFieldChange("health_report_url", "")}
                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          ) : (
            <div>
              <input
                type="file"
                id="health-report"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleHealthReportUpload}
                className="hidden"
              />
              <label htmlFor="health-report">
                <Button
                  type="button"
                  variant="outline"
                  disabled={uploadingReport}
                  className="border-white/10 text-white hover:bg-white/5 w-full"
                  onClick={() =>
                    document.getElementById("health-report")?.click()
                  }
                >
                  {uploadingReport ? (
                    <>
                      <Upload className="w-4 h-4 mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Choose file
                    </>
                  )}
                </Button>
              </label>
            </div>
          )}
        </Card>

        {/* Advanced Settings Tabs */}
        <Tabs defaultValue="location" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-[#151515] border border-white/5 p-1 rounded-2xl">
            <TabsTrigger
              value="location"
              className="rounded-xl data-[state=active]:bg-emerald-600"
            >
              <MapPin className="w-4 h-4 mr-2" />
              Location
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="rounded-xl data-[state=active]:bg-emerald-600"
            >
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Location Tab */}
          <TabsContent value="location" className="mt-6">
            <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
              <h3 className="text-xl font-bold text-white mb-6">
                Location Settings
              </h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-300 mb-2 block">Country</Label>
                  <Input
                    value={editedPreferences.location?.country || ""}
                    onChange={(e) =>
                      handleFieldChange("location", {
                        ...editedPreferences.location,
                        country: e.target.value,
                      })
                    }
                    placeholder="e.g., India"
                    className="bg-[#1A1A1A] border-white/10 text-white h-12"
                  />
                </div>
                <div>
                  <Label className="text-gray-300 mb-2 block">City</Label>
                  <Input
                    value={editedPreferences.location?.city || ""}
                    onChange={(e) =>
                      handleFieldChange("location", {
                        ...editedPreferences.location,
                        city: e.target.value,
                      })
                    }
                    placeholder="e.g., Mumbai"
                    className="bg-[#1A1A1A] border-white/10 text-white h-12"
                  />
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="mt-6">
            <Card className="bg-[#151515] border-white/5 rounded-3xl p-6">
              <h3 className="text-xl font-bold text-white mb-6">
                App Settings
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b border-white/5">
                  <div>
                    <p className="font-medium text-white">Dark Mode</p>
                    <p className="text-sm text-gray-400">
                      Use dark theme throughout the app
                    </p>
                  </div>
                  <Switch
                    checked={editedPreferences.dark_mode}
                    onCheckedChange={(checked) =>
                      handleFieldChange("dark_mode", checked)
                    }
                  />
                </div>
                <div className="flex items-center justify-between py-3 border-b border-white/5">
                  <div>
                    <p className="font-medium text-white">Notifications</p>
                    <p className="text-sm text-gray-400">
                      Receive product alerts and updates
                    </p>
                  </div>
                  <Switch
                    checked={editedPreferences.notifications_enabled}
                    onCheckedChange={(checked) =>
                      handleFieldChange("notifications_enabled", checked)
                    }
                  />
                </div>
                <div className="py-3">
                  <Label className="text-gray-300 mb-2 block">Language</Label>
                  <select
                    value={editedPreferences.language}
                    onChange={(e) =>
                      handleFieldChange("language", e.target.value)
                    }
                    className="w-full bg-[#1A1A1A] border border-white/10 text-white h-12 rounded-xl px-4"
                  >
                    <option value="en">English</option>
                    <option value="es">Spanish</option>
                    <option value="fr">French</option>
                    <option value="de">German</option>
                    <option value="it">Italian</option>
                  </select>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex gap-4">
          <Button
            onClick={handleSave}
            disabled={saveMutation.isPending || !hasUnsavedChanges}
            className="flex-1 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-semibold h-14 text-lg rounded-2xl disabled:opacity-50"
          >
            <Save className="w-5 h-5 mr-2" />
            {saveMutation.isPending ? "Saving..." : "Save changes"}
          </Button>

          {user && (
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-white/10 text-white hover:bg-white/5 h-14 px-8 rounded-2xl"
            >
              Sign out
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  MessageCircle,
  X,
  Send,
  Loader2,
  Sparkles,
  AlertCircle,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

export default function ChatBot({ contextProduct = null }) {
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [userPreferences, setUserPreferences] = useState(null);
  const [userName, setUserName] = useState("");
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      loadUserData().then(() => {
        initializeChat(userName);
      });
    }
  }, [isOpen]);

  const loadUserData = async () => {
    try {
      const user = await base44.auth.me();
      
      if (!user || !user.email) {
        console.warn('No user found or user email missing');
        setUserName("there");
        return;
      }
      
      setUserName(user.full_name?.split(" ")[0] || "there");

      // Load user preferences using created_by field (user email)
      try {
        const prefs = await base44.entities.UserPreference.filter({
          created_by: user.email,
        });
        
        if (prefs && prefs.length > 0) {
          setUserPreferences(prefs[0]);
          console.log('User preferences loaded successfully');
        } else {
          console.log('No user preferences found for user:', user.email);
          // User preferences will be created during onboarding or chat
        }
      } catch (prefsError) {
        console.error('Error loading user preferences:', prefsError);
        // Continue without preferences - they can be created later
      }
    } catch (error) {
      console.error("Could not load user data:", error);
      setUserName("there");
    }
  };

  const initializeChat = (name = null) => {
    const displayName = name || userName || "there";
    setMessages([
      {
        role: "assistant",
        content: `👋 Hi ${displayName}! I'm your AI nutrition assistant. I can help you understand ingredients, analyze nutritional content, suggest healthier alternatives, and answer any food-related questions. I also keep track of your health information from our conversations. What would you like to know?`,
      },
    ]);
  };

  const updatePreferencesMutation = useMutation({
    mutationFn: async (data) => {
      if (userPreferences) {
        return await base44.entities.UserPreference.update(
          userPreferences.id,
          data
        );
      } else {
        return await base44.entities.UserPreference.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["userPreferences"] });
      loadUserData(); // Reload updated preferences
    },
  });

  const extractAndUpdateHealthInfo = async (userMessage, assistantResponse) => {
    try {
      // Get current user to ensure we have email
      const user = await base44.auth.me();
      if (!user || !user.email) {
        console.warn('Cannot extract health info: user not found');
        return;
      }
      
      // Reload preferences to get latest data
      let currentPrefs = userPreferences;
      if (!currentPrefs || !currentPrefs.id) {
        try {
          const prefs = await base44.entities.UserPreference.filter({
            created_by: user.email,
          });
          if (prefs && prefs.length > 0) {
            currentPrefs = prefs[0];
            setUserPreferences(currentPrefs);
          } else {
            console.log('No user preferences found for health extraction');
            // Don't create preferences here - let user complete onboarding first
            return;
          }
        } catch (loadError) {
          console.error('Error loading preferences for health extraction:', loadError);
          return;
        }
      }
      
      if (!currentPrefs || !currentPrefs.id) {
        console.warn('Cannot extract health info: no user preferences found');
        return;
      }
      
      const currentAllergies = currentPrefs.allergies || "none";
      const currentConditions = Array.isArray(currentPrefs.conditions) 
        ? currentPrefs.conditions.join(", ") 
        : (currentPrefs.conditions || "none");
      
      // Use LLM to extract health information from the conversation
      const extraction = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this conversation and extract any NEW health information that should be added to the user's profile.
        
User said: "${userMessage}"
Assistant said: "${assistantResponse}"

Current user allergies: ${currentAllergies}
Current user conditions: ${currentConditions}

Extract ONLY NEW information in this JSON format:
{
  "new_allergies": ["array of new allergies mentioned - only if user explicitly states they HAVE the allergy"],
  "new_conditions": ["array of new health conditions mentioned - only if user explicitly states they HAVE the condition"],
  "has_new_info": boolean
}

Rules:
- Only extract if the user explicitly mentions they HAVE a new allergy/condition (e.g., "I have", "I'm allergic to", "I have been diagnosed with", "I'm having this allergy", "I developed")
- Do NOT extract potential/suggested allergies from assistant's recommendations
- Do NOT extract if already in current allergies/conditions
- Return has_new_info: false if no new information found
- Be conservative - only extract clear, explicit statements from the user
- Normalize allergy names (e.g., "peanut" not "peanuts", "milk" not "dairy")`,
        response_json_schema: {
          type: "object",
          properties: {
            new_allergies: { type: "array", items: { type: "string" } },
            new_conditions: { type: "array", items: { type: "string" } },
            has_new_info: { type: "boolean" },
          },
          required: ["has_new_info", "new_allergies", "new_conditions"],
        },
      });

      // Validate extraction response
      if (!extraction || typeof extraction !== 'object') {
        console.warn('Invalid extraction response:', extraction);
        return;
      }

      if (extraction.has_new_info === true) {
        let updateMessage = "";
        let hasUpdates = false;

        if (extraction.new_allergies && Array.isArray(extraction.new_allergies) && extraction.new_allergies.length > 0) {
          updateMessage += `New allergies added: ${extraction.new_allergies.join(", ")}. `;
          hasUpdates = true;
        }

        if (extraction.new_conditions && Array.isArray(extraction.new_conditions) && extraction.new_conditions.length > 0) {
          updateMessage += `New conditions added: ${extraction.new_conditions.join(", ")}.`;
          hasUpdates = true;
        }

        if (hasUpdates && currentPrefs.id) {
          try {
            await base44.entities.UserPreference.updateHealth(currentPrefs.id, {
              new_allergies: extraction.new_allergies || [],
              new_conditions: extraction.new_conditions || [],
            });
            
            // Reload user preferences
            await loadUserData();

            // Add system message to chat
            setMessages((prev) => [
              ...prev,
              {
                role: "system",
                content: `✅ Profile Updated: ${updateMessage.trim()} You can review and manage this in your Profile settings.`,
              },
            ]);

            toast.success("Health profile updated automatically");
          } catch (error) {
            console.error("Failed to update health info:", error);
            toast.error("Failed to update health profile: " + (error.message || 'Unknown error'));
          }
        }
      }
    } catch (error) {
      console.error("Failed to extract health info:", error);
      // Don't show error to user - this is a background process
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setLoading(true);

    try {
      // Reload user data to ensure we have latest preferences
      await loadUserData();
      
      // Get user to ensure we have email
      const user = await base44.auth.me();
      const userEmail = user?.email || 'user@example.com';
      
      // Reload preferences to ensure we have latest data
      let currentPreferences = userPreferences;
      if (!currentPreferences || !currentPreferences.id) {
        try {
          const prefs = await base44.entities.UserPreference.filter({
            created_by: userEmail,
          });
          if (prefs && prefs.length > 0) {
            currentPreferences = prefs[0];
            setUserPreferences(currentPreferences);
          }
        } catch (err) {
          console.error('Error reloading preferences:', err);
        }
      }
      
      // Build context with user health information
      let contextInfo = "";
      if (currentPreferences) {
        const allergies = currentPreferences.allergies || "none";
        const conditions = Array.isArray(currentPreferences.conditions) 
          ? currentPreferences.conditions.join(", ") 
          : (currentPreferences.conditions || "none");
        const dietaryRestrictions = Array.isArray(currentPreferences.dietary_restrictions)
          ? currentPreferences.dietary_restrictions.join(", ")
          : (currentPreferences.dietary_restrictions || "none");
        
        contextInfo = `
User Health Profile:
- Age: ${currentPreferences.age || "not specified"}
- Gender: ${currentPreferences.gender || "not specified"}
- Known Allergies: ${allergies}
- Health Conditions: ${conditions}
- Dietary Preferences: ${dietaryRestrictions}
- Additional Notes: ${currentPreferences.notes || "none"}

IMPORTANT: Always consider the user's allergies and health conditions when providing advice. Warn them about foods that contain their allergens or might affect their health conditions.`;
      }

      let prompt = `You are a helpful, personalized AI nutrition assistant. ${contextInfo ? 'You have access to the user\'s health profile.' : ''}

${contextInfo}

${
  contextProduct
    ? `User is currently viewing this product: ${JSON.stringify(contextProduct)}`
    : ""
}

User question: ${userMessage}

Provide clear, accurate, personalized advice based on the user's health profile. Be empathetic and helpful. If you recommend avoiding certain foods due to allergies or health conditions, explain why based on their specific profile. Always prioritize the user's safety and health.`;

      let response;
      let responseText = '';
      
      try {
        console.log('Sending LLM request with prompt length:', prompt.length);
        response = await base44.integrations.Core.InvokeLLM({
          prompt: prompt,
          add_context_from_internet: false,
        });
        
        console.log('LLM Response received:', typeof response, response);
        
        // Handle different response types from LLM
        if (typeof response === 'string') {
          // Direct string response - this is what Gemini returns
          responseText = response;
        } else if (response && typeof response === 'object') {
          // Object response - check for error first
          if (response.error) {
            console.error('LLM returned error:', response.error);
            throw new Error(response.error || 'Failed to generate response');
          }
          
          // Check for text property
          if (response.text) {
            responseText = response.text;
          } else if (response.message) {
            responseText = response.message;
          } else if (response.content) {
            responseText = response.content;
          } else {
            // Try to stringify the object (for debugging)
            console.warn('Unexpected response format:', response);
            responseText = JSON.stringify(response, null, 2);
          }
        } else {
          console.warn('Unexpected response type:', typeof response, response);
          responseText = String(response || 'No response received');
        }
        
        // Ensure we have valid response text
        if (!responseText || responseText.trim().length === 0) {
          console.error('Empty response text received');
          throw new Error('Empty response from AI');
        }
        
        console.log('Response text length:', responseText.length);
        console.log('Response text preview:', responseText.substring(0, 100));
        
        // Add assistant response to messages
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: responseText.trim() },
        ]);
        
        // Extract health info after successful response (async, don't wait)
        if (currentPreferences && currentPreferences.id) {
          extractAndUpdateHealthInfo(userMessage, responseText).catch(err => {
            console.error('Health info extraction failed (non-critical):', err);
          });
        }
        
      } catch (error) {
        console.error('LLM Invocation Error:', error);
        console.error('Error details:', {
          message: error.message,
          name: error.name,
          stack: error.stack
        });
        const errorMessage = error.message || 'Failed to generate response';
        throw new Error(errorMessage);
      }
    } catch (error) {
      console.error('ChatBot Error:', error);
      const errorMessage = error.message || 'Failed to generate response';
      
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: errorMessage.includes('Gemini') || errorMessage.includes('API key') 
            ? "Sorry, I'm having trouble connecting to the AI service. Please check if the backend server is running and the Gemini API key is configured correctly in server/.env file."
            : `Sorry, I encountered an error: ${errorMessage}. Please try again.`,
        },
      ]);
      
      toast.error('Failed to get AI response. Check console for details.');
    }

    setLoading(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    setMessages([]);
    initializeChat(userName);
  };

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-24 right-4 md:bottom-6 md:right-6 z-[60]"
            style={{ zIndex: 60 }}
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 shadow-2xl shadow-emerald-500/50 border-2 border-white/10"
            >
              <MessageCircle className="w-6 h-6 md:w-8 md:h-8 text-white" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, x: 20, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.95 }}
            className="fixed top-20 right-4 md:right-6 z-[60] w-[calc(100vw-2rem)] md:w-[400px] max-h-[calc(100vh-10rem)] flex flex-col"
            style={{ zIndex: 60 }}
          >
            <Card className="bg-[#151515] border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col h-full">
              {/* Header */}
              <div className="bg-gradient-to-r from-emerald-600 to-emerald-500 p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">
                      AI Nutrition Assistant
                    </h3>
                    <p className="text-xs text-white/80">
                      {userPreferences
                        ? "🟢 Personalized Mode"
                        : "Always here to help"}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Messages */}
              <div
                className="flex-1 overflow-y-auto p-4 space-y-4"
                style={{ maxHeight: "calc(100vh - 20rem)" }}
              >
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    {message.role === "system" ? (
                      <div className="bg-blue-500/20 border border-blue-500/30 rounded-2xl px-4 py-3 max-w-[85%]">
                        <p className="text-blue-300 text-sm leading-relaxed whitespace-pre-wrap flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                          <span>{message.content}</span>
                        </p>
                      </div>
                    ) : (
                      <div
                        className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                          message.role === "user"
                            ? "bg-emerald-600 text-white"
                            : "bg-[#1A1A1A] text-gray-100 border border-white/5"
                        }`}
                      >
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">
                          {message.content}
                        </p>
                      </div>
                    )}
                  </div>
                ))}

                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-[#1A1A1A] border border-white/5 rounded-2xl px-4 py-3">
                      <Loader2 className="w-5 h-5 text-emerald-500 animate-spin" />
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-4 border-t border-white/5">
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask about nutrition, ingredients..."
                    className="flex-1 bg-[#1A1A1A] border-white/10 text-white placeholder:text-gray-500"
                    disabled={loading}
                  />
                  <Button
                    onClick={handleSend}
                    disabled={loading || !input.trim()}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}


import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Leaf, AlertTriangle } from "lucide-react";
import NutriScoreBadge from "./NutriScoreBadge";
import EcoScoreBadge from "./EcoScoreBadge";

export default function ProductCard({ product }) {
  // Handle both ScannedProduct and Product entities
  const productId = product.product_id || product.id;
  const displayProduct = {
    id: productId,
    name: product.product_name || product.name,
    brand: product.product_brand || product.brand,
    image: product.product_image || product.image_url,
    nutriScore: product.nutri_score,
    ecoScore: product.eco_score,
    servingSize: product.serving_size,
    barcode: product.barcode,
  };

  return (
    <Link to={createPageUrl("ProductDetail") + `?id=${displayProduct.id}`}>
      <Card className="bg-[#151515] border-white/5 rounded-2xl overflow-hidden hover:border-emerald-500/30 transition-all duration-300 group cursor-pointer">
        {/* Product Image */}
        <div className="relative aspect-square bg-[#1A1A1A] overflow-hidden">
          {displayProduct.image ? (
            <img
              src={displayProduct.image}
              alt={displayProduct.name}
              className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Leaf className="w-16 h-16 text-gray-600" />
            </div>
          )}

          {/* Scores Overlay */}
          <div className="absolute top-3 right-3 flex gap-2">
            {displayProduct.nutriScore &&
              displayProduct.nutriScore !== "unknown" && (
                <NutriScoreBadge score={displayProduct.nutriScore} size="sm" />
              )}
            {displayProduct.ecoScore &&
              displayProduct.ecoScore !== "unknown" && (
                <EcoScoreBadge score={displayProduct.ecoScore} size="sm" />
              )}
          </div>
        </div>

        {/* Product Info */}
        <div className="p-4">
          <h3 className="font-semibold text-white text-lg mb-1 line-clamp-2 group-hover:text-emerald-400 transition-colors">
            {displayProduct.name}
          </h3>
          <p className="text-gray-400 text-sm mb-3">{displayProduct.brand}</p>

          {displayProduct.servingSize && (
            <Badge
              variant="secondary"
              className="bg-white/5 text-gray-300 text-xs"
            >
              {displayProduct.servingSize}
            </Badge>
          )}
        </div>
      </Card>
    </Link>
  );
}

import React from "react";
import { cn } from "@/lib/utils";
import { Leaf } from "lucide-react";

export default function EcoScoreBadge({
  score,
  size = "md",
  showLabel = true,
}) {
  const scoreUpper = score?.toUpperCase() || "E";

  const sizes = {
    sm: "w-10 h-10 text-sm",
    md: "w-14 h-14 text-lg",
    lg: "w-20 h-20 text-2xl",
    xl: "w-32 h-32 text-4xl",
  };

  const colors = {
    A: "bg-gradient-to-br from-green-600 to-green-700",
    B: "bg-gradient-to-br from-lime-600 to-lime-700",
    C: "bg-gradient-to-br from-yellow-600 to-yellow-700",
    D: "bg-gradient-to-br from-orange-600 to-orange-700",
    E: "bg-gradient-to-br from-red-600 to-red-700",
    unknown: "bg-gray-500",
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className={cn(
          "rounded-xl flex items-center justify-center font-bold text-white shadow-lg",
          sizes[size],
          colors[scoreUpper] || colors.unknown
        )}
      >
        {scoreUpper !== "UNKNOWN" ? (
          scoreUpper
        ) : (
          <Leaf className="w-1/2 h-1/2" />
        )}
      </div>
      {showLabel && size !== "sm" && (
        <span className="text-xs text-gray-400 font-medium">Eco-Score</span>
      )}
    </div>
  );
}


import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Check, TrendingUp, Leaf } from "lucide-react";
import NutriScoreBadge from "./NutriScoreBadge";
import EcoScoreBadge from "./EcoScoreBadge";

export default function RecommendationCard({
  product,
  matchScore = 0,
  reasons = [],
}) {
  const displayReasons = reasons.slice(0, 4);
  const stars = Math.round((matchScore / 100) * 5);

  return (
    <Card className="bg-gradient-to-br from-[#151515] to-[#1A1A1A] border-emerald-500/20 rounded-2xl overflow-hidden hover:border-emerald-500/40 transition-all duration-300">
      <div className="flex flex-col md:flex-row gap-6 p-6">
        {/* Product Image */}
        <div className="w-full md:w-40 aspect-square bg-[#0F0F0F] rounded-xl overflow-hidden flex-shrink-0">
          {product.image_url ? (
            <img
              src={product.image_url}
              alt={product.name}
              className="w-full h-full object-contain p-4"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Leaf className="w-12 h-12 text-gray-600" />
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="flex-1 space-y-4">
          <div>
            <h3 className="text-xl font-bold text-white mb-1">
              {product.name}
            </h3>
            <p className="text-gray-400">{product.brand}</p>
          </div>

          {/* Scores */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <NutriScoreBadge
                score={product.nutri_score}
                size="sm"
                showLabel={false}
              />
              <span className="text-sm text-gray-400">Nutri-Score</span>
            </div>
            <div className="flex items-center gap-2">
              <EcoScoreBadge
                score={product.eco_score}
                size="sm"
                showLabel={false}
              />
              <span className="text-sm text-gray-400">Eco-Score</span>
            </div>
          </div>

          {/* Match Score */}
          <div className="flex items-center gap-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`w-5 h-5 ${
                  i < stars
                    ? "fill-yellow-500 text-yellow-500"
                    : "text-gray-600"
                }`}
              />
            ))}
            <span className="text-emerald-400 font-semibold ml-2">
              {matchScore}% match
            </span>
          </div>

          {/* Reasons */}
          {displayReasons.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-medium text-gray-300">
                Why this product:
              </p>
              <div className="space-y-1">
                {displayReasons.map((reason, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-400">{reason}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Link
              to={createPageUrl("ProductDetail") + `?id=${product.id}`}
              className="flex-1"
            >
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                View Details
              </Button>
            </Link>
            <Button
              variant="outline"
              className="border-white/10 text-white hover:bg-white/5"
            >
              Add to List
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}


import React, { useEffect, useRef, useState, useCallback } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Camera, Keyboard, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function BarcodeScanner({ onScan, isActive = true }) {
  const html5QrCodeRef = useRef(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [error, setError] = useState(null);
  const [showManualInput, setShowManualInput] = useState(false);
  const [manualBarcode, setManualBarcode] = useState("");
  const [scanning, setScanning] = useState(false);
  const scannerContainerRef = useRef(null);
  const hasStartedRef = useRef(false);
  const isMountedRef = useRef(true);

  // CRITICAL: Stop camera immediately and forcefully
  const stopScannerImmediately = useCallback(() => {
    console.log("🛑 FORCE STOPPING CAMERA");
    const scanner = html5QrCodeRef.current;
    
    // CRITICAL: Stop all video tracks first (aggressive cleanup)
    try {
      // Get all video tracks from all video elements
      const videoElements = document.querySelectorAll('video');
      videoElements.forEach((video) => {
        if (video.srcObject) {
          const stream = video.srcObject;
          if (stream && stream.getTracks) {
            stream.getTracks().forEach((track) => {
              track.stop();
              console.log("🛑 Stopped video track:", track.kind);
            });
          }
          video.srcObject = null;
        }
      });
    } catch (e) {
      console.log("Error stopping video tracks:", e.message);
    }
    
    if (scanner) {
      // Stop the scanner immediately - don't wait
      scanner.stop()
        .then(() => {
          console.log("✅ Scanner stopped successfully");
          try {
            scanner.clear();
          } catch (e) {
            console.log("Clear error (non-critical):", e.message);
          }
          html5QrCodeRef.current = null;
        })
        .catch((err) => {
          console.log("⚠️ Stop error, forcing clear:", err.message);
          // Force clear even if stop fails
          try {
            scanner.clear();
          } catch (e) {
            console.log("Force clear error:", e.message);
          }
          html5QrCodeRef.current = null;
        });
    }
    
    // IMMEDIATELY reset all state - don't wait for async operations
    setCameraActive(false);
    setScanning(false);
    hasStartedRef.current = false;
  }, []);

  // CRITICAL: Stop camera when component becomes inactive or unmounts
  useEffect(() => {
    isMountedRef.current = true;
    
    // If not active, stop immediately
    if (!isActive) {
      console.log("🚫 Component not active - stopping camera");
      stopScannerImmediately();
      return;
    }
    
    // Cleanup on unmount
    return () => {
      isMountedRef.current = false;
      console.log("🧹 Component unmounting - stopping camera");
      stopScannerImmediately();
    };
  }, [isActive, stopScannerImmediately]);

  const startScanner = async () => {
    // CRITICAL CHECKS: Don't start if not active, already scanning, or unmounted
    if (!isActive || !isMountedRef.current || scanning || cameraActive || hasStartedRef.current) {
      console.log("⏸️ Scanner start aborted:", { isActive, isMounted: isMountedRef.current, scanning, cameraActive, hasStarted: hasStartedRef.current });
      return;
    }

    try {
      setError(null);
      setScanning(true);
      hasStartedRef.current = true;

      // Wait a bit to ensure DOM is ready
      await new Promise(resolve => setTimeout(resolve, 300));

      // CRITICAL: Check again if still active and mounted
      if (!isActive || !isMountedRef.current) {
        console.log("🚫 Component became inactive during initialization");
        stopScannerImmediately();
        return;
      }

      // Check if container exists
      const container = document.getElementById("barcode-scanner");
      if (!container) {
        throw new Error("Scanner container not found");
      }

      // Clear any existing scanner instance
      if (html5QrCodeRef.current) {
        try {
          await html5QrCodeRef.current.stop().catch(() => {});
          html5QrCodeRef.current.clear().catch(() => {});
        } catch (e) {
          // Ignore cleanup errors
        }
        html5QrCodeRef.current = null;
      }

      // Initialize html5-qrcode
      const html5QrCode = new Html5Qrcode("barcode-scanner");
      html5QrCodeRef.current = html5QrCode;

      // OPTIMIZED Configuration for barcode scanning
      // html5-qrcode supports barcodes (EAN-13, EAN-8, UPC-A, UPC-E, Code 128, CODE_39, etc.)
      // via ZXing library - it automatically detects both QR codes and barcodes
      // 
      // IMPORTANT: html5-qrcode DOES support barcodes, but has known reliability issues
      // The library uses ZXing which is not actively maintained
      // We enable experimental BarcodeDetector API for better performance on Chrome/Edge
      const config = {
        fps: 10, // Balanced FPS for detection
        // Use a wide scanning box optimized for horizontal barcodes
        // Barcodes are wide and shallow, so we need a wide scanning area
        qrbox: function(viewfinderWidth, viewfinderHeight) {
          // Wide box: 85% width, 25% height (perfect for horizontal barcodes)
          const width = Math.floor(viewfinderWidth * 0.85);
          const height = Math.max(Math.floor(viewfinderHeight * 0.25), 80);
          console.log(`📐 Scanning area: ${width}x${height}px (viewport: ${viewfinderWidth}x${viewfinderHeight}px)`);
          return { width, height };
        },
        aspectRatio: 1.777778, // 16:9
        disableFlip: false, // Allow rotation
        verbose: false, // Enable for debugging (creates lots of console logs)
        // CRITICAL: Enable experimental BarcodeDetector API
        // This uses browser's native API (Chrome/Edge) - much better for barcodes
        // Falls back to ZXing if not available
        experimentalFeatures: {
          useBarCodeDetectorIfSupported: true
        },
        rememberLastUsedCamera: false
      };
      
      // Verify html5-qrcode is working
      console.log("✅ html5-qrcode library loaded successfully");
      console.log("📚 Library supports: QR codes, EAN-13, EAN-8, UPC-A, UPC-E, Code 128, CODE_39, etc.");
      console.log("🔧 Using experimental BarcodeDetector API:", config.experimentalFeatures.useBarCodeDetectorIfSupported);

      // Camera configuration - try to get best available camera
      let cameraConfig = { facingMode: "environment" };
      
      // Try to get camera list for better device compatibility
      try {
        const cameras = await Html5Qrcode.getCameras();
        if (cameras && cameras.length > 0) {
          // Prefer back camera
          const backCamera = cameras.find(c => c.label && c.label.toLowerCase().includes("back"));
          if (backCamera) {
            cameraConfig = { deviceId: { exact: backCamera.id } };
            console.log("📷 Using back camera:", backCamera.label);
          } else {
            // Use first available camera
            cameraConfig = { deviceId: { exact: cameras[0].id } };
            console.log("📷 Using camera:", cameras[0].label);
          }
        }
      } catch (camError) {
        console.log("⚠️ Could not get camera list, using default:", camError.message);
        // Fall back to facingMode
        cameraConfig = { facingMode: "environment" };
      }
      
      console.log("🎥 Starting barcode scanner...");
      console.log("📷 Camera:", cameraConfig);
      console.log("⚙️ Config:", { fps: config.fps, qrbox: config.qrbox, aspectRatio: config.aspectRatio });
      
      // Start scanning with optimized configuration
      await html5QrCode.start(
        cameraConfig,
        config,
        (decodedText, decodedResult) => {
          // SUCCESS: Code detected by html5-qrcode!
          console.log("🎉🎉🎉 CODE DETECTED:", decodedText);
          console.log("📊 Detection method:", decodedResult?.result?.format?.formatName || "Unknown format");
          console.log("📊 Full result object:", decodedResult);
          
          // html5-qrcode can detect both QR codes and barcodes
          // Barcodes are typically numeric (EAN-13: 13 digits, EAN-8: 8 digits, UPC-A: 12 digits)
          const trimmedText = decodedText?.trim() || "";
          
          // Check if it's a barcode (numeric, 8-14 digits) or QR code
          if (trimmedText.length >= 8 && /^\d+$/.test(trimmedText)) {
            // This is likely a barcode (EAN-13, UPC-A, etc.)
            console.log("✅ BARCODE detected (numeric):", trimmedText);
            console.log("📏 Barcode length:", trimmedText.length, "digits");
            stopScannerImmediately();
            if (onScan) {
              onScan(trimmedText);
            }
          } else if (trimmedText.length > 0) {
            // Could be QR code or other format - process it anyway
            console.log("✅ CODE detected (non-numeric, might be QR):", trimmedText);
            stopScannerImmediately();
            if (onScan) {
              onScan(trimmedText);
            }
          } else {
            console.warn("⚠️ Empty code detected:", decodedText);
          }
        },
        (errorMessage) => {
          // These are EXPECTED errors during scanning
          // html5-qrcode continuously tries to detect codes, so "not found" errors are normal
          const expectedErrors = [
            "NotFoundException",
            "No MultiFormat Readers",
            "No code detected",
            "QR code parse error",
            "No QR code found",
            "Exception",
            "Continuing jsQR",
            "QR code parse error, error =",
            "No MultiFormat Readers could be found",
            "No QR code found!",
            "No MultiFormat Readers could be found for the image"
          ];
          
          const isExpected = errorMessage && expectedErrors.some(err => 
            errorMessage.includes(err)
          );
          
          // Only log unexpected errors (these might indicate real problems)
          if (!isExpected && errorMessage) {
            console.warn("⚠️ Unexpected scanner error:", errorMessage.substring(0, 150));
          }
          // Note: Expected errors are normal - the scanner is working and trying to detect codes
        }
      );
      
      console.log("✅ Scanner started and ready");

      setCameraActive(true);
      setScanning(false);
    } catch (err) {
      console.error("❌ Scanner error:", err);
      setError(err.message || "Camera access denied. Please use manual barcode entry.");
      setCameraActive(false);
      setScanning(false);
      hasStartedRef.current = false;
      
      // Clean up on error
      if (html5QrCodeRef.current) {
        try {
          await html5QrCodeRef.current.stop().catch(() => {});
          html5QrCodeRef.current.clear().catch(() => {});
        } catch (cleanupErr) {
          // Ignore cleanup errors
        }
        html5QrCodeRef.current = null;
      }
    }
  };

  const stopScanner = async () => {
    if (html5QrCodeRef.current) {
      try {
        await html5QrCodeRef.current.stop().catch(() => {});
        await html5QrCodeRef.current.clear().catch(() => {});
      } catch (err) {
        console.error("Error stopping scanner:", err);
      }
      html5QrCodeRef.current = null;
    }
    setCameraActive(false);
    setScanning(false);
    hasStartedRef.current = false;
  };

  const handleScanSuccess = (barcode) => {
    if (barcode && barcode.trim()) {
      stopScanner();
      onScan(barcode.trim());
    }
  };

  const handleManualSubmit = () => {
    if (manualBarcode.trim()) {
      stopScannerImmediately();
      onScan(manualBarcode.trim());
      setManualBarcode("");
      setShowManualInput(false);
    }
  };

  const retryScanner = async () => {
    await stopScanner();
    setError(null);
    hasStartedRef.current = false;
    setTimeout(() => {
      if (isActive && isMountedRef.current) {
        startScanner();
      }
    }, 500);
  };

  // Start scanner ONLY when component is active
  useEffect(() => {
    // If not active, don't start
    if (!isActive) {
      return;
    }

    // Don't start if already started or scanning
    if (hasStartedRef.current || cameraActive || scanning) {
      return;
    }

    console.log("🚀 Initializing scanner (component is active)");
    
    // Delay to ensure DOM is ready
    const timer = setTimeout(() => {
      // Final check: must still be active and mounted
      if (isActive && isMountedRef.current && !hasStartedRef.current && !cameraActive) {
        const container = document.getElementById("barcode-scanner");
        if (container) {
          console.log("✅ Starting scanner...");
          startScanner();
        }
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [isActive]); // Only depend on isActive

  return (
    <>
      <div className="relative w-full aspect-video max-w-2xl mx-auto rounded-2xl overflow-hidden bg-black">
        {/* Scanner Container */}
        <div
          id="barcode-scanner"
          ref={scannerContainerRef}
          className="w-full h-full min-h-[400px]"
        />

        {/* Loading State */}
        {scanning && !cameraActive && !error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-10">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-white">Starting camera...</p>
            </div>
          </div>
        )}

        {/* Scanning Overlay - Clean with small corner designs */}
        {cameraActive && !error && (
          <div className="absolute inset-0 pointer-events-none z-10">
            {/* Scanning Frame - Positioned higher to give more space */}
            <div className="absolute inset-0 flex items-center justify-center pt-8">
              {/* Wide, shallow frame for barcode scanning */}
              <div className="relative w-[85%] max-w-[700px] h-40 border-2 border-emerald-500 rounded-xl shadow-lg">
                {/* Small L-shaped corner indicators - clean and minimal */}
                <div className="absolute -top-1 -left-1 w-6 h-6 border-t-2 border-l-2 border-emerald-400 rounded-tl"></div>
                <div className="absolute -top-1 -right-1 w-6 h-6 border-t-2 border-r-2 border-emerald-400 rounded-tr"></div>
                <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-2 border-l-2 border-emerald-400 rounded-bl"></div>
                <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-2 border-r-2 border-emerald-400 rounded-br"></div>
                
                {/* Enhanced scanning line animation - smooth sweep */}
                <div className="absolute inset-0 overflow-hidden rounded-xl">
                  {/* Main scanning line - bright and smooth */}
                  <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent animate-scan-line shadow-md shadow-emerald-400/30"></div>
                </div>
              </div>
            </div>
            
            {/* Darkened edges with gradient for focus */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/70 pointer-events-none"></div>
            <div className="absolute inset-0 bg-gradient-to-l from-black/50 via-transparent to-black/50 pointer-events-none"></div>

            {/* Minimal manual entry button at bottom */}
            <div className="absolute bottom-8 left-0 right-0 text-center pointer-events-auto px-4">
              <Button
                onClick={async () => {
                  stopScannerImmediately();
                  setShowManualInput(true);
                }}
                variant="outline"
                size="sm"
                className="border-emerald-400/50 text-white hover:bg-emerald-500/20 bg-black/50 hover:scale-105 transition-transform shadow-lg"
              >
                <Keyboard className="w-4 h-4 mr-2" />
                Enter Manually
              </Button>
            </div>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/90 z-20">
            <div className="text-center p-6 max-w-md">
              <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
              <p className="text-red-400 mb-4">{error}</p>
              <div className="space-y-3">
                <Button
                  onClick={retryScanner}
                  variant="outline"
                  className="w-full text-white border-white/10 hover:bg-white/5"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Try Camera Again
                </Button>
                <Button
                  onClick={() => {
                    setError(null);
                    setShowManualInput(true);
                  }}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  <Keyboard className="w-4 h-4 mr-2" />
                  Enter Barcode Manually
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Info Alert */}
      {!error && cameraActive && (
        <Alert className="mt-4 bg-blue-500/10 border-blue-500/20">
          <AlertCircle className="h-4 w-4 text-blue-400" />
          <AlertDescription className="text-blue-300">
            <strong>Tip:</strong> Position the barcode within the frame. Ensure good lighting and hold the device steady. The scanner will automatically detect the barcode.
          </AlertDescription>
        </Alert>
      )}

      {/* Manual Barcode Input Dialog */}
      <Dialog open={showManualInput} onOpenChange={setShowManualInput}>
        <DialogContent className="bg-[#151515] border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">
              Enter Barcode Manually
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <Input
              value={manualBarcode}
              onChange={(e) => setManualBarcode(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleManualSubmit()}
              placeholder="Enter barcode number (e.g., 8909081003363)"
              className="bg-[#1A1A1A] border-white/10 text-white text-lg h-14"
              autoFocus
            />
            <Button
              onClick={handleManualSubmit}
              disabled={!manualBarcode.trim()}
              className="w-full bg-emerald-600 hover:bg-emerald-700 h-12"
            >
              Scan Product
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <style>{`
        /* Main scanning line animation - smooth vertical sweep */
        @keyframes scan-line {
          0% {
            transform: translateY(-5px);
            opacity: 0;
          }
          5% {
            opacity: 1;
          }
          95% {
            opacity: 1;
          }
          100% {
            transform: translateY(calc(100% + 5px));
            opacity: 0;
          }
        }
        
        /* Apply scanning line animation */
        .animate-scan-line {
          animation: scan-line 2s linear infinite;
        }
        
        /* Scanner container styling */
        #barcode-scanner {
          width: 100%;
          height: 100%;
          min-height: 400px;
          position: relative;
          background: #000;
        }
        
        /* Video styling */
        #barcode-scanner video {
          width: 100% !important;
          height: 100% !important;
          object-fit: cover !important;
          display: block !important;
        }
        
        /* Hide html5-qrcode default scanning box border/UI but allow scanning to work */
        /* We show our custom overlay instead */
        #barcode-scanner #qr-shaded-region,
        #barcode-scanner .qr-shaded-region {
          opacity: 0 !important;
          pointer-events: none !important;
        }
        
        /* Hide the default scanning box border but keep the scanning functionality */
        #barcode-scanner div[style*="border"][style*="dashed"],
        #barcode-scanner div[style*="border"][style*="solid"]:not(.custom-overlay):not(.keep-border) {
          border: none !important;
          opacity: 0 !important;
          pointer-events: none !important;
        }
        
        /* Canvas is used for scanning - keep it but make it invisible */
        /* Don't hide it completely as it's needed for barcode detection */
        #barcode-scanner canvas {
          opacity: 0 !important;
          pointer-events: none !important;
          position: absolute !important;
          z-index: -1 !important;
        }
        
        /* Hide images */
        #barcode-scanner img {
          display: none !important;
        }
        
        /* Ensure video is visible and properly sized */
        #barcode-scanner video {
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
          width: 100% !important;
          height: 100% !important;
          object-fit: cover !important;
        }
        
        /* Ensure the scanner container works properly */
        #barcode-scanner > div:first-child {
          width: 100% !important;
          height: 100% !important;
          position: relative !important;
        }
      `}</style>
    </>
  );
}

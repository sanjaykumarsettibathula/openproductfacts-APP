import * as React from "react"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "./button"

const SheetContext = React.createContext({})

const Sheet = ({ children }) => {
  return <SheetContext.Provider value={{}}>{children}</SheetContext.Provider>
}

const SheetTrigger = React.forwardRef(({ asChild, children, ...props }, ref) => {
  const [isOpen, setIsOpen] = React.useState(false)

  if (asChild && React.isValidElement(children)) {
    return React.cloneElement(children, {
      ...props,
      onClick: () => setIsOpen(true),
    })
  }

  return (
    <button ref={ref} onClick={() => setIsOpen(true)} {...props}>
      {children}
    </button>
  )
})
SheetTrigger.displayName = "SheetTrigger"

const SheetContent = React.forwardRef(({ side = "right", className, children, ...props }, ref) => {
  const [isOpen, setIsOpen] = React.useState(true)

  if (!isOpen) return null

  const sideClasses = {
    right: "inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
    left: "inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
    top: "inset-x-0 top-0 border-b",
    bottom: "inset-x-0 bottom-0 border-t",
  }

  return (
    <>
      <div
        className="fixed inset-0 z-40 bg-black/80"
        onClick={() => setIsOpen(false)}
      />
      <div
        ref={ref}
        className={cn(
          "fixed z-50 gap-4 bg-[#0F0F0F] p-6 shadow-lg transition ease-in-out",
          sideClasses[side],
          className
        )}
        {...props}
      >
        {children}
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-4 rounded-sm"
          onClick={() => setIsOpen(false)}
        >
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </Button>
      </div>
    </>
  )
})
SheetContent.displayName = "SheetContent"

export { Sheet, SheetTrigger, SheetContent }


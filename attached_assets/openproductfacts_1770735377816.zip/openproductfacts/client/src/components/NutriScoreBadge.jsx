import React from "react";
import { cn } from "@/lib/utils";

export default function NutriScoreBadge({
  score,
  size = "md",
  showLabel = true,
}) {
  const scoreUpper = score?.toUpperCase() || "E";

  const sizes = {
    sm: "w-10 h-10 text-sm",
    md: "w-14 h-14 text-lg",
    lg: "w-20 h-20 text-2xl",
    xl: "w-32 h-32 text-4xl",
  };

  const colors = {
    A: "nutri-score-a",
    B: "nutri-score-b",
    C: "nutri-score-c",
    D: "nutri-score-d",
    E: "nutri-score-e",
    unknown: "bg-gray-500",
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className={cn(
          "rounded-xl flex items-center justify-center font-bold text-white shadow-lg",
          sizes[size],
          colors[scoreUpper] || colors.unknown
        )}
      >
        {scoreUpper !== "UNKNOWN" ? scoreUpper : "?"}
      </div>
      {showLabel && size !== "sm" && (
        <span className="text-xs text-gray-400 font-medium">Nutri-Score</span>
      )}
    </div>
  );
}
